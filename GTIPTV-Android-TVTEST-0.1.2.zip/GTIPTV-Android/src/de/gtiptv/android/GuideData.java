// SPDX-License-Identifier: GPL-2.0-or-later
package de.gtiptv.android;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.Html;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

final class GuideData {
    static final class Program {
        String title="",description="";
        long start=0,end=0;
        int percent(long now){if(start<=0||end<=start)return -1;return (int)Math.max(0,Math.min(100,(now-start)*100/(end-start)));}
    }
    static final class Schedule {
        final List<Program> programs=new ArrayList<>();
        final long fetched=System.currentTimeMillis();
        Program now(long time){for(Program p:programs)if(p.start<=time&&p.end>time)return p;return null;}
        List<Program> next(long time){List<Program> result=new ArrayList<>();for(Program p:programs)if(p.start>time)result.add(p);return result;}
    }
    static long timestamp(JSONObject o,String epoch,String text){
        long value=o.optLong(epoch,0);if(value>0)return value<100000000000L?value*1000:value;
        String raw=o.optString(text);if(raw.isEmpty())return 0;
        try{SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.ROOT);format.setLenient(false);return format.parse(raw).getTime();}catch(Exception e){return 0;}
    }
    static Schedule schedule(Catalog.Source source,Catalog.Item item) throws Exception {
        Schedule result=new Schedule();if(!source.type.equals("xtream"))return result;
        JSONObject root=new JSONObject(Catalog.api(source,"get_short_epg","&stream_id="+Catalog.encode(item.id)+"&limit=8"));
        JSONArray rows=root.optJSONArray("epg_listings");if(rows==null)return result;
        for(int n=0;n<rows.length();n++){
            JSONObject o=rows.optJSONObject(n);if(o==null)continue;Program p=new Program();
            p.title=plain(Catalog.decode(o.optString("title")));p.description=plain(Catalog.decode(o.optString("description")));
            p.start=timestamp(o,"start_timestamp","start");p.end=timestamp(o,"stop_timestamp","end");
            if(p.end==0)p.end=timestamp(o,"end_timestamp","stop");
            if(p.start>0&&p.end>p.start)result.programs.add(p);
        }
        Collections.sort(result.programs,(a,b)->Long.compare(a.start,b.start));return result;
    }
    private static String plain(String text){return Html.fromHtml(text,Html.FROM_HTML_MODE_LEGACY).toString().trim();}
    static Bitmap logo(String address) throws Exception {
        if(address.isEmpty()||address.equals("null"))return null;
        URL url=new URL(address);HttpURLConnection connection=null;
        try{
            for(int redirect=0;redirect<5;redirect++){
                if(!url.getProtocol().equals("http")&&!url.getProtocol().equals("https"))return null;
                connection=(HttpURLConnection)url.openConnection();connection.setConnectTimeout(5000);connection.setReadTimeout(7000);connection.setInstanceFollowRedirects(false);
                int code=connection.getResponseCode();
                if(code>=300&&code<400){String location=connection.getHeaderField("Location");if(location==null)return null;
                    URL next=new URL(url,location);if(url.getProtocol().equals("https")&&!next.getProtocol().equals("https"))return null;
                    connection.disconnect();connection=null;url=next;continue;}
                if(code<200||code>=300)return null;
                byte[] data;
                try(InputStream in=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] buffer=new byte[8192];int count;while((count=in.read(buffer))!=-1){if(Thread.currentThread().isInterrupted()||out.size()+count>4*1024*1024)return null;out.write(buffer,0,count);}data=out.toByteArray();}
                BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(data,0,data.length,options);
                if(options.outWidth<=0||options.outHeight<=0||options.outWidth>8192||options.outHeight>8192)return null;
                options.inSampleSize=1;while(Math.max(options.outWidth,options.outHeight)/options.inSampleSize>768)options.inSampleSize*=2;
                options.inJustDecodeBounds=false;return BitmapFactory.decodeByteArray(data,0,data.length,options);
            }return null;
        }finally{if(connection!=null)connection.disconnect();}
    }
}
