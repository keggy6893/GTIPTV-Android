# Prüfstand Android-Test 0.1.0

Stand: 14.10.2026.

- Java-Produktionsquellen gegen Android API 35 kompiliert; keine Compilerfehler.
- Ressourcen/Manifest mit Android SDK Build Tools 36.0.0 verarbeitet.
- DEX mit minSdk 26 erstellt.
- APK erzeugt; Ausrichtung und APK-Signaturen v2/v3 erfolgreich geprüft.
- Paketname de.gtiptv.android, versionCode 1, targetSdk 34 bestätigt.
- Android-TV-Launcher-Eintrag und Internetberechtigung im APK-Manifest bestätigt.
- Sechs übernommene PNG-Dateien bytegleich mit der hochgeladenen VU-Sicherung.
- 19 Katalog-/Netzwerktests mit synthetischen lokalen Fixtures bestanden:
  Kontoprüfung, Ablehnung falscher Anmeldung, Kategorien, Film-/Episodendaten,
  numerische Staffelsortierung, URL-Kodierung, M3U-Gruppen und relative URLs,
  Ablehnung ungültiger/leerer M3U-Antworten, Redirects, Redirect-Limit, HTTP-Fehler.
- Keine echten IPTV-Zugangsdaten oder externen Provider für Tests verwendet.
- Build.ps1 und Install-TV.ps1 erfolgreich mit dem PowerShell-Sprachparser geprüft.

Noch nicht geprüft: tatsächlicher Start auf Android/TCL, Fernbedienungsfokus,
Bildlayout am TV, Keystore-Persistenz auf dem Gerät, Wiedergabe echter Streams,
Weiterschauen im Gerätebetrieb und Windows-Build mit dem lokalen Java 25/SDK 37.0.
Ein erfolgreicher Build bestätigt keine vollständige 1:1-Portierung.

Die APK wurde mit Android API 35 gebaut; Build.ps1 verwendet die auf dem
Windows-PC installierte SDK-Plattform. Die Android-Version des TV muss dafür
nicht geändert werden.
