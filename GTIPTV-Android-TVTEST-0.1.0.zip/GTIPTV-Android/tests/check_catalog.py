"""Host fixture runner. Usage: python check_catalog.py JAVA_CLASSPATH

Classpath: compiled Catalog/CatalogChecks plus a host org.json implementation.
This script never connects to a provider, receiver, or television.
"""
import json
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit


class Fixture(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def do_GET(self):
        request = urlsplit(self.path)
        query = parse_qs(request.query)
        if request.path in ('/redirect', '/loop'):
            self.send_response(302)
            self.send_header('Location', '/ok' if request.path == '/redirect' else '/loop')
            self.end_headers()
            return
        if request.path == '/failure':
            self.send_error(503)
            return
        if request.path == '/ok':
            response = b'ok'
        else:
            action = query.get('action', [''])[0]
            fixtures = {
                '': {'user_info': {'auth': 0 if query.get('username') == ['denied'] else 1, 'status': 'Active'}},
                'get_vod_categories': [{'category_id': '7', 'category_name': 'Test films'}],
                'get_vod_streams': [{'stream_id': 123, 'name': 'Synthetic film', 'container_extension': 'mkv', 'category_id': '7'}],
                'get_series_info': {'episodes': {'10': [{'id': 201, 'title': 'Later', 'episode_num': 1}], '2': [{'id': 200, 'title': 'Earlier', 'episode_num': 1}]}},
            }
            response = json.dumps(fixtures.get(action, [])).encode()
        self.send_response(200)
        self.send_header('Content-Length', str(len(response)))
        self.end_headers()
        self.wfile.write(response)


if __name__ == '__main__':
    with ThreadingHTTPServer(('127.0.0.1', 0), Fixture) as server:
        threading.Thread(target=server.serve_forever, daemon=True).start()
        result = subprocess.run(['java', '-cp', sys.argv[1], 'de.gtiptv.android.CatalogChecks', f'http://127.0.0.1:{server.server_port}'])
        server.shutdown()
    raise SystemExit(result.returncode)
