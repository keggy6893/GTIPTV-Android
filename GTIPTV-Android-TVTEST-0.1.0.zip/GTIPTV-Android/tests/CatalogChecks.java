package de.gtiptv.android;

import java.util.List;

/** Host tests with synthetic sources only. Requires org.json as host test runtime. */
public final class CatalogChecks {
    private static int count=0;
    private static void check(boolean value,String name){if(!value)throw new AssertionError(name);count++;}
    private interface Action {void run() throws Exception;}
    private static void rejects(Action action,String name) throws Exception {
        boolean rejected=false;try{action.run();}catch(Exception e){rejected=true;}check(rejected,name);
    }
    public static void main(String[] args) throws Exception {
        String base=args[0];Catalog.Source source=new Catalog.Source();source.name="Synthetic";source.server=base;source.user="test user";source.password="p&/x";
        check(Catalog.normalize(base+"/player_api.php").equals(base),"normalize API endpoint");
        rejects(()->Catalog.normalize("file:///etc/passwd"),"reject local-file source");
        rejects(()->Catalog.normalize("https://user:password@example.invalid"),"reject URL userinfo");
        check(Catalog.check(source).optString("status").equals("Active"),"authenticate active account");
        source.user="denied";rejects(()->Catalog.check(source),"reject invalid account");source.user="test user";
        check(Catalog.categories(source,"movie").get("7").equals("Test films"),"read movie categories");
        List<Catalog.Item> movies=Catalog.items(source,"movie","7");
        check(movies.size()==1&&movies.get(0).id.equals("123"),"read VOD item");
        check(Catalog.stream(source,movies.get(0)).contains("test%20user/p%26%2Fx/123.mkv"),"encode stream path credentials");
        Catalog.Item series=new Catalog.Item();series.id="55";
        List<Catalog.Item> episodes=Catalog.episodes(source,series);
        check(episodes.size()==2&&episodes.get(0).name.startsWith("S2")&&episodes.get(1).name.startsWith("S10"),"sort seasons numerically");
        Catalog.Source m3u=new Catalog.Source();m3u.id="playlist";m3u.server=base+"/folder/list.m3u";
        List<Catalog.Item> channels=Catalog.parseM3u(m3u,"#EXTM3U\r\n#EXTINF:-1 group-title=\"News, local\",Channel, one\r\n../stream.ts\r\n#EXTINF:-1,Second\r\nhttps://example.invalid/two\r\n");
        check(channels.size()==2&&channels.get(0).name.equals("Channel, one"),"parse quoted commas and display names");
        check(channels.get(0).category.equals("News, local"),"parse M3U group");
        check(channels.get(0).url.equals(base+"/stream.ts"),"resolve relative stream URL");
        check(channels.get(1).category.equals("Ohne Kategorie"),"reset absent M3U group");
        check(Catalog.Item.from(channels.get(0).json()).key().equals(channels.get(0).key()),"round-trip item identity");
        rejects(()->Catalog.parseM3u(m3u,"<html>not a playlist</html>"),"reject HTML playlist response");
        rejects(()->Catalog.parseM3u(m3u,"#EXTM3U\n"),"reject empty playlist");
        check(Catalog.get(base+"/redirect").equals("ok"),"follow HTTP redirect");
        rejects(()->Catalog.get(base+"/loop"),"bound redirect loops");
        rejects(()->Catalog.get(base+"/failure"),"reject HTTP error");
        System.out.println("PASS: "+count+" catalog and network checks (synthetic fixtures only)");
    }
}
