// SPDX-License-Identifier: GPL-2.0-or-later
// Independent Android port, 2026. Design/artwork Copyright (C) 2026 VicTuS59.
package de.gtiptv.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class MainActivity extends Activity {
    private static final int WHITE=Color.WHITE, MUTED=0xffbac8e2, CYAN=0xff21c4fa;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService workers=Executors.newFixedThreadPool(2);
    private final ArrayDeque<Runnable> history=new ArrayDeque<>();
    private final Map<String,Drawable.ConstantState> artCache=new LinkedHashMap<>();
    private final List<Catalog.Source> sources=new ArrayList<>();
    private final List<Catalog.Item> favorites=new ArrayList<>();
    private final LinkedHashMap<String,JSONObject> resumes=new LinkedHashMap<>();
    private final Map<String,List<Catalog.Item>> m3uCache=new LinkedHashMap<>();
    private PrivateStore store;
    private Runnable screen;
    private int selectedSource=0, generation=0;
    private Future<?> pending;
    private ProgressDialog progress;
    private VideoView video;
    private Catalog.Item playing;
    private boolean videoPrepared=false, foreground=true;
    private int playbackPosition=0;
    private String playerUrl="";
    private TextView sourceTitle,sourceStatus,sourceMeta;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();store=new PrivateStore(this);
        try {
            JSONArray a=new JSONArray(store.read("sources","[]"));for(int n=0;n<a.length();n++)sources.add(Catalog.Source.from(a.getJSONObject(n)));
            JSONArray f=new JSONArray(store.read("favorites","[]"));for(int n=0;n<f.length();n++)favorites.add(Catalog.Item.from(f.getJSONObject(n)));
            JSONArray r=new JSONArray(store.read("resume","[]"));for(int n=0;n<r.length();n++){JSONObject o=r.getJSONObject(n);resumes.put(o.getString("key"),o);}
            String active=store.read("selected","");for(int n=0;n<sources.size();n++)if(sources.get(n).id.equals(active))selectedSource=n;
        }catch(Exception e){message("Lokale Daten konnten nicht vollständig gelesen werden. Bitte Quellen prüfen.");}
        showWelcome();
    }
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)immersive();}
    private int dp(float n){return Math.round(getResources().getDisplayMetrics().density*n);}
    private void message(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    private void alert(String title,String text){new AlertDialog.Builder(this).setTitle(title).setMessage(text).setPositiveButton("OK",null).show();}
    private void navigate(Runnable target){if(screen!=null)history.push(screen);target.run();}
    private void install(View root,Runnable renderer){generation++;screen=renderer;setContentView(root);immersive();}
    private Catalog.Source active(){return sources.isEmpty()?null:sources.get(Math.floorMod(selectedSource,sources.size()));}
    private Catalog.Source sourceFor(Catalog.Item item){for(Catalog.Source s:sources)if(s.id.equals(item.source))return s;return null;}
    private void saveSources() throws Exception {
        JSONArray a=new JSONArray();for(Catalog.Source s:sources)a.put(s.json());store.write("sources",a.toString());
        store.write("selected",active()==null?"":active().id);
    }
    private Drawable art(String name){
        try {
            Drawable.ConstantState cached=artCache.get(name);if(cached!=null)return cached.newDrawable(getResources());
            try(InputStream in=getAssets().open("art/"+name)){Drawable d=Drawable.createFromStream(in,name);if(d!=null&&d.getConstantState()!=null)artCache.put(name,d.getConstantState());return d;}
        }catch(Exception e){return null;}
    }
    private Drawable box(int fill,int stroke,int width){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(9));if(width>0)d.setStroke(dp(width),stroke);return d;}
    private Drawable buttonBackground(){
        StateListDrawable state=new StateListDrawable();state.addState(new int[]{android.R.attr.state_focused},box(0x80234472,CYAN,3));
        state.addState(new int[]{android.R.attr.state_pressed},box(0x99234472,CYAN,3));state.addState(new int[]{},box(0x00000000,0,0));return state;
    }
    private TextView text(String value,float size,int color){TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private TextView button(String value,Runnable click){TextView t=text(value,20,WHITE);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);t.setPadding(dp(12),dp(10),dp(12),dp(10));t.setBackground(buttonBackground());t.setOnClickListener(v->click.run());return t;}
    private interface Job<T>{T run() throws Exception;}
    private interface Done<T>{void accept(T result);}
    private <T> void task(String label,Job<T> work,Done<T> done){
        if(progress!=null){message("Bitte den laufenden Vorgang abwarten oder mit Zurück abbrechen.");return;}
        final int token=generation;
        final ProgressDialog dialog=new ProgressDialog(this);progress=dialog;dialog.setMessage(label);dialog.setCancelable(true);
        dialog.setOnCancelListener(d->{generation++;if(pending!=null)pending.cancel(true);progress=null;});dialog.show();
        pending=workers.submit(()->{
            try{T result=work.run();ui.post(()->{if(progress==dialog){dialog.dismiss();progress=null;}if(!isFinishing()&&token==generation)done.accept(result);});}
            catch(Exception e){ui.post(()->{if(progress==dialog){dialog.dismiss();progress=null;}if(!isFinishing()&&token==generation)
                alert("Vorgang fehlgeschlagen","Keine verwertbare Antwort erhalten. Bitte Adresse, Zugangsdaten, Anbieterstatus und Netzwerk prüfen. Gespeicherte Zugangsdaten werden nicht angezeigt.");});}
        });
    }
    private ImageView background(String file){ImageView image=new ImageView(this);image.setImageDrawable(art(file));image.setScaleType(ImageView.ScaleType.FIT_XY);image.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);return image;}

    // Original Enigma2 design coordinates, uniformly scaled and letterboxed to 16:9.
    private final class Design extends ViewGroup {
        final Map<View,float[]> geometry=new LinkedHashMap<>();
        Design(){super(MainActivity.this);setBackgroundColor(0xff050914);setFocusable(false);}
        void put(View v,float x,float y,float w,float h,float font){geometry.put(v,new float[]{x,y,w,h,font});addView(v);}
        @Override protected void onMeasure(int ws,int hs){
            int w=MeasureSpec.getSize(ws),h=MeasureSpec.getSize(hs);float scale=Math.min(w/1920f,h/1080f);setMeasuredDimension(w,h);
            for(Map.Entry<View,float[]> e:geometry.entrySet()){float[] r=e.getValue();View v=e.getKey();if(v instanceof TextView&&r[4]>0)((TextView)v).setTextSize(TypedValue.COMPLEX_UNIT_PX,r[4]*scale);
                v.measure(MeasureSpec.makeMeasureSpec(Math.max(1,Math.round(r[2]*scale)),MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(Math.max(1,Math.round(r[3]*scale)),MeasureSpec.EXACTLY));}
        }
        @Override protected void onLayout(boolean changed,int l,int t,int r,int b){
            float scale=Math.min(getWidth()/1920f,getHeight()/1080f);int ox=Math.round((getWidth()-1920*scale)/2),oy=Math.round((getHeight()-1080*scale)/2);
            for(Map.Entry<View,float[]> e:geometry.entrySet()){float[] p=e.getValue();View v=e.getKey();int x=ox+Math.round(p[0]*scale),y=oy+Math.round(p[1]*scale);v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());}
        }
    }
    private void label(Design d,String text,int x,int y,int w,int h,int size,int color){d.put(text(text,size,color),x,y,w,h,size);}
    private void footer(Design d,String text){TextView t=text(text,24,MUTED);t.setGravity(Gravity.CENTER);d.put(t,35,985,1850,70,24);}
    private void showWelcome(){
        Design d=new Design();d.put(background("welcome-vector-r88-1080.png"),0,0,1920,1080,0);
        label(d,"GT IPTV Player Pro",212,105,370,105,26,WHITE);
        label(d,"SICHERE QUELLENVERBINDUNG",92,250,470,42,21,CYAN);
        label(d,"Willkommen",92,292,490,90,56,WHITE);
        label(d,"Quelle auswählen und verbinden,\num Fernsehen zu starten.",92,390,470,120,28,MUTED);
        label(d,"Android TV · Test 0.1.0",92,800,470,55,18,MUTED);
        label(d,"GESPEICHERTE QUELLE",720,105,1000,42,22,WHITE);
        sourceTitle=text("",32,WHITE);d.put(sourceTitle,1050,225,680,100,32);
        sourceStatus=text("",24,CYAN);d.put(sourceStatus,1050,330,680,48,24);
        sourceMeta=text("",22,MUTED);d.put(sourceMeta,1050,378,680,78,22);
        int[] xs={695,977,1263,1548};String[] labels={"VERBINDEN","QUELLEN VERWALTEN","QUELLE HINZUFÜGEN","YouTube"};
        Runnable[] actions={this::connectActive,()->navigate(this::showSources),()->editSource(null),this::openYouTube};
        TextView first=null;
        for(int n=0;n<4;n++){
            TextView b=button(labels[n],actions[n]);b.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);b.setPadding(0,0,0,dp(16));
            b.setOnKeyListener((v,code,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;
                if(code==KeyEvent.KEYCODE_DPAD_UP||code==KeyEvent.KEYCODE_DPAD_DOWN){if(!sources.isEmpty()){selectedSource=Math.floorMod(selectedSource+(code==KeyEvent.KEYCODE_DPAD_UP?-1:1),sources.size());refreshSource();}return true;}return false;});
            d.put(b,xs[n],545,268,298,21);if(n==0)first=b;
        }
        label(d,"↑ ↓ Quelle wählen     ← → Aktion wählen",720,847,1050,28,18,MUTED);
        footer(d,"Pfeiltasten: Auswahl     OK: Bestätigen     Menü: Einstellungen     Zurück: Beenden");
        install(d,this::showWelcome);refreshSource();if(first!=null)first.requestFocus();
    }
    private void refreshSource(){
        Catalog.Source s=active();sourceTitle.setText(s==null?"Noch keine Quelle gespeichert":s.name);
        sourceStatus.setText(s==null?"Bitte Quelle hinzufügen":"Gespeichert · Verbindung noch nicht geprüft");
        sourceMeta.setText(s==null?"Xtream Codes oder M3U-URL":s.type.equals("m3u")?"M3U · Live-TV":"Xtream Codes · Live-TV, Filme und Serien");
    }
    private void connectActive(){Catalog.Source s=active();if(s==null){editSource(null);return;}
        task("Quelle wird geprüft …",()->{
            if(s.type.equals("m3u")){List<Catalog.Item> items=Catalog.m3u(s);return (Object)items;}
            return (Object)Catalog.check(s);
        },result->{if(s.type.equals("m3u")){
                @SuppressWarnings("unchecked") List<Catalog.Item> list=(List<Catalog.Item>)result;m3uCache.put(s.id,list);
            }
            try{saveSources();}catch(Exception e){message("Auswahl konnte nicht gespeichert werden.");}
            navigate(()->showDashboard(s));
        });
    }
    private void showDashboard(Catalog.Source s){
        Design d=new Design();d.put(background("dashboard-neon-r96.png"),0,0,1920,1080,0);
        ImageView left=background("global-neon-v0912.png");d.put(left,0,104,500,878,0);
        d.put(background("dashboard-menu-discovery.png"),0,104,500,878,0);
        label(d,"GT",40,15,72,70,46,CYAN);label(d,"IPTV PLAYER PRO",112,15,500,70,46,WHITE);
        label(d,s.name,620,15,500,70,32,WHITE);label(d,"VERBUNDEN",1450,15,300,70,29,0xff80ecb5);
        TextView clock=text(new SimpleDateFormat("HH:mm",Locale.GERMANY).format(new Date()),39,WHITE);d.put(clock,1770,15,130,70,39);
        String[] names={"LIVE-TV","TV-ARCHIV","FILME","FILME ENTDECKEN","SERIEN","WEITERSCHAUEN","FAVORITEN","EINSTELLUNGEN"};
        String[] keys={"live","catchup","movie","discover","series","continue","favorites","settings"};
        TextView first=null;
        for(int n=0;n<8;n++){final String key=keys[n];TextView b=button(names[n],()->openAction(s,key));
            b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);b.setPadding(dp(18),0,0,0);d.put(b,25,112+n*108,452,98,30);if(n==0)first=b;}
        TextView hero=button("LIVE-TV\nDeine Sender direkt starten",()->openAction(s,"live"));hero.setGravity(Gravity.TOP|Gravity.LEFT);hero.setPadding(dp(20),dp(20),0,0);d.put(hero,507,103,1386,447,48);
        int[] xs={507,853,1211,1565},widths={333,345,340,329};String[] quick={"FILME","SERIEN","WEITERSCHAUEN","FAVORITEN"};String[] qa={"movie","series","continue","favorites"};
        for(int n=0;n<4;n++){final String key=qa[n];TextView b=button(quick[n],()->openAction(s,key));b.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);b.setPadding(0,0,0,dp(18));d.put(b,xs[n],567,widths[n],419,n==2?27:36);}
        footer(d,"Pfeiltasten: Auswahl     OK: Öffnen     Zurück: Quellen");install(d,()->showDashboard(s));if(first!=null)first.requestFocus();
    }
    private void openAction(Catalog.Source s,String key){
        if(key.equals("settings")){navigate(this::showSettings);return;}
        if(key.equals("favorites")){showSaved(false);return;}
        if(key.equals("continue")){showSaved(true);return;}
        if(key.equals("catchup")||key.equals("discover")){
            alert(key.equals("catchup")?"TV-Archiv":"Filme entdecken","Diese Funktion der VU-Vorlage ist in Android-Test 0.1.0 noch nicht umgesetzt.");return;
        }
        if(s.type.equals("m3u")){
            if(!key.equals("live")){alert("M3U-Quelle","Diese Quelle stellt in dieser Version ausschließlich Live-TV bereit.");return;}
            List<Catalog.Item> cached=m3uCache.get(s.id);
            if(cached!=null){openM3uCategories(s,cached);return;}
            task("Senderliste wird geladen …",()->Catalog.m3u(s),items->{m3uCache.put(s.id,items);openM3uCategories(s,items);});return;
        }
        task("Kategorien werden geladen …",()->Catalog.categories(s,key),cats->navigate(()->showCategories(s,key,cats,null)));
    }
    private void openM3uCategories(Catalog.Source s,List<Catalog.Item> items){LinkedHashMap<String,String> cats=new LinkedHashMap<>();cats.put("","Alle");
        for(Catalog.Item i:items)cats.put(i.category,i.category);navigate(()->showCategories(s,"live",cats,items));}
    private FrameLayout page(String title,LinearLayout column){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(0xff050914);root.addView(background("global-neon-v0912.png"),new FrameLayout.LayoutParams(-1,-1));
        column.setOrientation(LinearLayout.VERTICAL);column.setPadding(dp(36),dp(20),dp(36),dp(16));root.addView(column,new FrameLayout.LayoutParams(-1,-1));
        TextView heading=text(title,29,WHITE);heading.setTypeface(null,Typeface.BOLD);column.addView(heading,new LinearLayout.LayoutParams(-1,dp(60)));return root;
    }
    private ArrayAdapter<String> listAdapter(List<String> rows){return new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,rows){
        @Override public View getView(int position,View convert,ViewGroup parent){TextView t=(TextView)super.getView(position,convert,parent);t.setTextColor(WHITE);t.setTextSize(22);t.setMinHeight(dp(58));t.setPadding(dp(18),dp(10),dp(18),dp(10));t.setMaxLines(3);return t;}
    };}
    private ListView list(LinearLayout column){ListView list=new ListView(this);list.setSelector(box(0xcc24456a,CYAN,2));list.setDividerHeight(dp(3));column.addView(list,new LinearLayout.LayoutParams(-1,0,1));return list;}
    private void listHint(LinearLayout column,String hint){TextView t=text(hint,16,MUTED);column.addView(t,new LinearLayout.LayoutParams(-1,dp(42)));}
    private void showCategories(Catalog.Source s,String kind,LinkedHashMap<String,String> cats,List<Catalog.Item> m3u){
        LinearLayout col=new LinearLayout(this);FrameLayout root=page(s.name+" · "+kindLabel(kind)+" · Kategorien",col);
        List<String> ids=new ArrayList<>(cats.keySet());ListView lv=list(col);lv.setAdapter(listAdapter(new ArrayList<>(cats.values())));
        lv.setOnItemClickListener((p,v,pos,id)->{
            String category=ids.get(pos);
            if(m3u!=null){List<Catalog.Item> result=new ArrayList<>();for(Catalog.Item item:m3u)if(category.isEmpty()||item.category.equals(category))result.add(item);
                navigate(()->showItems(s.name+" · "+cats.get(category),result));}
            else task("Inhalte werden geladen …",()->Catalog.items(s,kind,category),result->navigate(()->showItems(s.name+" · "+cats.get(category),result)));
        });listHint(col,"OK: Kategorie öffnen     Zurück: Dashboard");install(root,()->showCategories(s,kind,cats,m3u));lv.requestFocus();
    }
    private String kindLabel(String kind){return kind.equals("live")?"Live-TV":kind.equals("movie")?"Filme":kind.equals("series")?"Serien":"Episoden";}
    private boolean isFavorite(Catalog.Item item){for(Catalog.Item f:favorites)if(f.key().equals(item.key()))return true;return false;}
    private void showItems(String title,List<Catalog.Item> all){
        LinearLayout col=new LinearLayout(this);FrameLayout root=page(title+"  ("+all.size()+")",col);
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(WHITE);search.setHintTextColor(MUTED);search.setTextSize(20);search.setHint("In dieser Liste suchen …");col.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));
        List<Catalog.Item> visible=new ArrayList<>(all);List<String> names=new ArrayList<>();
        for(Catalog.Item item:all)names.add((isFavorite(item)?"★  ":"")+item.name);
        ArrayAdapter<String> adapter=listAdapter(names);ListView lv=list(col);lv.setAdapter(adapter);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence q,int a,int b,int c){
            visible.clear();adapter.clear();String term=q.toString().toLowerCase(Locale.ROOT);
            for(Catalog.Item item:all)if(item.name.toLowerCase(Locale.ROOT).contains(term)){visible.add(item);adapter.add((isFavorite(item)?"★  ":"")+item.name);}adapter.notifyDataSetChanged();
        }public void afterTextChanged(Editable e){}});
        search.setOnEditorActionListener((t,action,event)->{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);lv.requestFocus();return true;});
        lv.setOnItemClickListener((p,v,pos,id)->{if(pos<visible.size())openItem(visible.get(pos));});
        lv.setOnItemLongClickListener((p,v,pos,id)->{if(pos<visible.size())itemOptions(visible.get(pos));return true;});
        lv.setOnKeyListener((v,code,event)->{if(event.getAction()==KeyEvent.ACTION_DOWN&&(code==KeyEvent.KEYCODE_MENU||code==KeyEvent.KEYCODE_PROG_YELLOW)){
            int pos=lv.getSelectedItemPosition();if(pos>=0&&pos<visible.size())itemOptions(visible.get(pos));return true;}return false;});
        if(all.isEmpty()){TextView empty=text("Keine Einträge vorhanden.",22,MUTED);col.addView(empty,1);}
        listHint(col,"OK: Öffnen/Abspielen     OK halten oder Menü: Favorit / Infos / EPG     Zurück: Zurück");
        install(root,()->showItems(title,all));lv.requestFocus();
    }
    private void openItem(Catalog.Item item){Catalog.Source s=sourceFor(item);if(s==null){alert("Quelle fehlt","Die zugehörige Quelle wurde entfernt. Bitte den Eintrag löschen und aus einer vorhandenen Quelle erneut hinzufügen.");return;}
        if(item.kind.equals("series")){task("Episoden werden geladen …",()->Catalog.episodes(s,item),items->navigate(()->showItems(item.name,items)));return;}
        JSONObject saved=resumes.get(item.key());int position=saved==null?0:saved.optInt("position");
        if(position>10000&&!item.kind.equals("live")){
            new AlertDialog.Builder(this).setTitle(item.name).setMessage("Bei "+duration(position)+" fortsetzen?")
                .setPositiveButton("Fortsetzen",(d,w)->startPlayer(s,item,position)).setNegativeButton("Von vorne",(d,w)->startPlayer(s,item,0)).setNeutralButton("Abbrechen",null).show();
        }else startPlayer(s,item,0);
    }
    private void itemOptions(Catalog.Item item){List<String> options=new ArrayList<>();options.add(isFavorite(item)?"Aus Favoriten entfernen":"Zu Favoriten hinzufügen");options.add("Informationen");
        Catalog.Source s=sourceFor(item);boolean epg=item.kind.equals("live")&&s!=null&&s.type.equals("xtream");if(epg)options.add("EPG anzeigen");if(resumes.containsKey(item.key()))options.add("Aus Weiterschauen entfernen");
        new AlertDialog.Builder(this).setTitle(item.name).setItems(options.toArray(new String[0]),(d,n)->{
            String selected=options.get(n);
            if(n==0){toggleFavorite(item);if(screen!=null)screen.run();}
            else if(n==1)alert(item.name,item.description.isEmpty()?"Keine Beschreibung vorhanden.":item.description);
            else if(selected.equals("EPG anzeigen"))task("EPG wird geladen …",()->Catalog.epg(s,item),body->alert(item.name,body));
            else {resumes.remove(item.key());saveResume();if(screen!=null)screen.run();}
        }).show();
    }
    private void toggleFavorite(Catalog.Item item){
        List<Catalog.Item> before=new ArrayList<>(favorites);
        if(isFavorite(item)){for(int n=favorites.size()-1;n>=0;n--)if(favorites.get(n).key().equals(item.key()))favorites.remove(n);}else favorites.add(item);
        try{JSONArray a=new JSONArray();for(Catalog.Item f:favorites)a.put(f.json());store.write("favorites",a.toString());message(isFavorite(item)?"Favorit gespeichert":"Favorit entfernt");}
        catch(Exception e){favorites.clear();favorites.addAll(before);alert("Speichern fehlgeschlagen","Favoriten konnten nicht gespeichert werden.");}
    }
    private void showSaved(boolean resume){navigate(()->renderSaved(resume));}
    private void renderSaved(boolean resume){List<Catalog.Item> items=new ArrayList<>();
        if(resume){List<JSONObject> data=new ArrayList<>(resumes.values());java.util.Collections.reverse(data);for(JSONObject o:data){JSONObject i=o.optJSONObject("item");if(i!=null)items.add(Catalog.Item.from(i));}}
        else items.addAll(favorites);showItems(resume?"Weiterschauen":"Favoriten",items);screen=()->renderSaved(resume);
    }
    private String duration(int ms){int s=ms/1000;return String.format(Locale.GERMANY,"%d:%02d:%02d",s/3600,(s/60)%60,s%60);}
    private void startPlayer(Catalog.Source source,Catalog.Item item,int position){
        try{playerUrl=Catalog.stream(source,item);}catch(Exception e){alert("Wiedergabe","Streamadresse konnte nicht erstellt werden.");return;}
        if(screen!=null)history.push(screen);playing=item;playbackPosition=position;videoPrepared=false;
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);video=new VideoView(this);
        FrameLayout.LayoutParams params=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);root.addView(video,params);
        TextView heading=text(item.name,20,WHITE);heading.setBackgroundColor(0x88000000);heading.setPadding(dp(16),0,dp(16),0);
        FrameLayout.LayoutParams top=new FrameLayout.LayoutParams(-1,dp(48),Gravity.TOP);root.addView(heading,top);
        MediaController controls=new MediaController(this);controls.setAnchorView(video);video.setMediaController(controls);
        VideoView thisVideo=video;
        video.setOnPreparedListener(mp->{if(video!=thisVideo)return;videoPrepared=true;mp.setScreenOnWhilePlaying(true);if(playbackPosition>0)thisVideo.seekTo(playbackPosition);if(foreground)thisVideo.start();ui.postDelayed(()->{if(video==thisVideo)heading.setVisibility(View.GONE);},5000);});
        video.setOnCompletionListener(mp->{if(video!=thisVideo)return;if(playing!=null){resumes.remove(playing.key());saveResume();}playing=null;stopPlayer(false);back();});
        video.setOnErrorListener((mp,what,extra)->{if(video!=thisVideo)return true;stopPlayer(true);back();alert("Wiedergabe fehlgeschlagen","Android konnte diesen Stream nicht abspielen. Ursache kann die Streamadresse, Erreichbarkeit oder das Format sein. Die VU-Wiedergabe ist damit noch nicht gleichwertig nachgebildet.");return true;});
        install(root,()->{});getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);video.setVideoURI(Uri.parse(playerUrl));video.requestFocus();
    }
    private void saveResume(){try{JSONArray a=new JSONArray();for(JSONObject o:resumes.values())a.put(o);store.write("resume",a.toString());}catch(Exception e){message("Wiedergabestand konnte nicht gespeichert werden.");}}
    private void rememberPosition(){
        if(video==null||playing==null||playing.kind.equals("live")||!videoPrepared)return;
        try{int pos=video.getCurrentPosition(),len=video.getDuration();playbackPosition=pos;if(pos<10000)return;
            if(len>0&&len-pos<15000)resumes.remove(playing.key());else{JSONObject o=new JSONObject().put("key",playing.key()).put("item",playing.json()).put("position",pos).put("duration",len);
                resumes.remove(playing.key());resumes.put(playing.key(),o);while(resumes.size()>100)resumes.remove(resumes.keySet().iterator().next());}
            saveResume();
        }catch(Exception e){message("Wiedergabestand konnte nicht gelesen werden.");}
    }
    private void stopPlayer(boolean remember){if(remember)rememberPosition();if(video!=null){video.setOnErrorListener(null);video.setOnCompletionListener(null);video.stopPlayback();video=null;}playing=null;videoPrepared=false;getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
    private void showSources(){
        LinearLayout col=new LinearLayout(this);FrameLayout root=page("Quellen verwalten",col);
        TextView add=button("+ Quelle hinzufügen",()->editSource(null));col.addView(add,new LinearLayout.LayoutParams(-1,dp(54)));
        List<String> names=new ArrayList<>();for(Catalog.Source s:sources)names.add(s.name+"   ·   "+(s.type.equals("m3u")?"M3U":"Xtream Codes"));
        ListView lv=list(col);lv.setAdapter(listAdapter(names));lv.setOnItemClickListener((p,v,pos,id)->{
            Catalog.Source s=sources.get(pos);new AlertDialog.Builder(this).setTitle(s.name).setItems(new String[]{"Auswählen und verbinden","Bearbeiten","Löschen"},(dialog,n)->{
                if(n==0){selectedSource=pos;connectActive();}else if(n==1)editSource(s);else new AlertDialog.Builder(this).setTitle("Quelle löschen?").setMessage(s.name+" wird aus dieser Android-App entfernt.")
                    .setPositiveButton("Löschen",(a,b)->{List<Catalog.Source> before=new ArrayList<>(sources);int old=selectedSource;sources.remove(s);selectedSource=0;
                        try{saveSources();m3uCache.remove(s.id);showSources();}catch(Exception e){sources.clear();sources.addAll(before);selectedSource=old;alert("Fehler","Quelle konnte nicht gelöscht werden.");}}).setNegativeButton("Abbrechen",null).show();
            }).show();
        });listHint(col,"OK: Aktionen     Zurück: Zurück");install(root,this::showSources);if(sources.isEmpty())add.requestFocus();else lv.requestFocus();
    }
    private EditText field(LinearLayout parent,String hint,String value,boolean password){EditText input=new EditText(this);input.setHint(hint);input.setText(value);input.setTextColor(WHITE);input.setHintTextColor(MUTED);input.setSingleLine(true);input.setTextSize(20);
        input.setInputType(InputType.TYPE_CLASS_TEXT|(password?InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_TEXT_VARIATION_NORMAL));parent.addView(input,new LinearLayout.LayoutParams(-1,dp(58)));return input;}
    private void editSource(Catalog.Source existing){
        if(existing==null){new AlertDialog.Builder(this).setTitle("Quelle hinzufügen").setItems(new String[]{"Xtream Codes · Live-TV, Filme, Serien","M3U-URL · Live-TV"},(d,n)->navigate(()->sourceForm(null,n==0?"xtream":"m3u"))).show();}
        else navigate(()->sourceForm(existing,existing.type));
    }
    private void sourceForm(Catalog.Source existing,String type){
        LinearLayout col=new LinearLayout(this);FrameLayout root=page((existing==null?"Quelle hinzufügen":"Quelle bearbeiten")+" · "+(type.equals("m3u")?"M3U":"Xtream Codes"),col);
        ScrollView scroll=new ScrollView(this);LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);scroll.addView(form);col.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        EditText name=field(form,"Name",existing==null?"":existing.name,false);
        EditText server=field(form,type.equals("m3u")?"Vollständige M3U-URL (http:// oder https://)":"Server-URL (http:// oder https://)",existing==null?"":existing.server,false);
        EditText user=null,password=null;
        if(type.equals("xtream")){user=field(form,"Benutzername",existing==null?"":existing.user,false);password=field(form,"Passwort",existing==null?"":existing.password,true);}
        final EditText userField=user,passField=password;
        TextView test=button("Verbindung testen",()->{
            Catalog.Source s=formSource(existing,type,name,server,userField,passField);if(s==null)return;
            task("Verbindung wird geprüft …",()->{
                if(type.equals("m3u"))return "Verbindung erfolgreich.\nLive-TV-Sender: "+Catalog.m3u(s).size();
                Catalog.check(s);int count=Catalog.items(s,"live","").size();return "Verbindung erfolgreich.\nLive-TV-Sender: "+count;
            },result->alert("Verbindungstest",result));
        });form.addView(test,new LinearLayout.LayoutParams(-1,dp(58)));
        TextView save=button("Quelle speichern",()->{
            Catalog.Source s=formSource(existing,type,name,server,userField,passField);if(s==null)return;
            List<Catalog.Source> before=new ArrayList<>(sources);int old=selectedSource;
            if(existing==null){sources.add(s);selectedSource=sources.size()-1;}else{int pos=sources.indexOf(existing);if(pos<0){alert("Quelle fehlt","Bitte Quellenverwaltung neu öffnen.");return;}sources.set(pos,s);selectedSource=pos;}
            try{saveSources();m3uCache.remove(s.id);back();message("Quelle gespeichert");}catch(Exception e){sources.clear();sources.addAll(before);selectedSource=old;alert("Speichern fehlgeschlagen","Die Quelle wurde nicht gespeichert.");}
        });form.addView(save,new LinearLayout.LayoutParams(-1,dp(58)));
        listHint(col,"Zugangsdaten werden lokal verschlüsselt gespeichert. Ein Verbindungstest speichert noch nichts.");install(root,()->sourceForm(existing,type));name.requestFocus();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN|WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }
    private Catalog.Source formSource(Catalog.Source existing,String type,EditText name,EditText server,EditText user,EditText password){
        try{Catalog.Source s=new Catalog.Source();if(existing!=null)s.id=existing.id;s.type=type;s.name=name.getText().toString().trim();s.server=Catalog.normalize(server.getText().toString());
            if(user!=null)s.user=user.getText().toString().trim();if(password!=null)s.password=password.getText().toString();
            if(s.name.isEmpty()||(type.equals("xtream")&&(s.user.isEmpty()||s.password.isEmpty())))throw new Exception("missing");return s;
        }catch(Exception e){alert("Eingaben prüfen","Bitte Name, gültige HTTP(S)-Adresse und bei Xtream Benutzername und Passwort eingeben.");return null;}
    }
    private void showSettings(){
        LinearLayout col=new LinearLayout(this);FrameLayout root=page("Einstellungen · Android-Test 0.1.0",col);
        String[] names={"Quellen verwalten","Senderlisten-Cache leeren","YouTube öffnen","Über diese Android-Version","Lizenz und Herkunft"};ListView lv=list(col);List<String> rows=new ArrayList<>();java.util.Collections.addAll(rows,names);lv.setAdapter(listAdapter(rows));
        lv.setOnItemClickListener((p,v,n,id)->{if(n==0)navigate(this::showSources);else if(n==1){m3uCache.clear();message("Senderlisten-Cache geleert");}else if(n==2)openYouTube();
            else if(n==3)alert("Stand der Portierung","Vorlage: GT IPTV Player Pro 1.3.0 für Enigma2.\nAndroid-Test: 0.1.0.\n\nEnthalten: Originalgrafiken für Einstieg und Dashboard; Xtream/M3U; Kategorien, Suche, Episoden, Favoriten, Wiedergabestand und kurzer Xtream-EPG.\n\nNoch offen: Stalker/MAG, TV-Archiv, TMDB-Entdecken, Posteransichten, Downloads, Untertitelverwaltung, Wetter, Themes und vollständige Player-Gleichwertigkeit.\n\nEin 1:1-Laufzeitvergleich auf dem TCL ist noch erforderlich.");
            else showLicense();
        });listHint(col,"OK: Öffnen     Zurück: Zurück");install(root,this::showSettings);lv.requestFocus();
    }
    private void showLicense(){
        LinearLayout col=new LinearLayout(this);FrameLayout root=page("Lizenz und Herkunft",col);ScrollView scroll=new ScrollView(this);TextView body=text("",16,MUTED);body.setTextIsSelectable(true);scroll.addView(body);col.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        String intro="Android-Portierung auf Grundlage von GT IPTV Player Pro.\nOriginalgrafiken und Design: Copyright (C) 2026 VicTuS59.\nGPL-2.0-or-later. Geänderte Android-Version, kein unverändertes Originalrelease.\n\n";
        try(InputStream in=getAssets().open("LICENSE.txt")){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);body.setText(intro+new String(out.toByteArray(),"UTF-8"));}catch(Exception e){body.setText(intro+"Vollständiger Lizenztext liegt im Projektordner licenses.");}
        install(root,this::showLicense);scroll.requestFocus();
    }
    private void openYouTube(){
        Intent launch=getPackageManager().getLaunchIntentForPackage("com.google.android.youtube.tv");if(launch==null)launch=getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
        try{if(launch!=null)startActivity(launch);else startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/")));}catch(Exception e){alert("YouTube","Keine passende YouTube-App oder Browser-App verfügbar.");}
    }
    private void back(){if(video!=null)stopPlayer(true);if(history.isEmpty()){showWelcome();return;}history.pop().run();}
    @Override public void onBackPressed(){if(video!=null){back();return;}if(!history.isEmpty()){back();return;}
        new AlertDialog.Builder(this).setTitle("GT IPTV Player Pro beenden?").setPositiveButton("Beenden",(d,n)->finish()).setNegativeButton("Zurück",null).show();}
    @Override public boolean onKeyDown(int key,KeyEvent event){if(key==KeyEvent.KEYCODE_MENU&&video==null){navigate(this::showSettings);return true;}return super.onKeyDown(key,event);}
    @Override protected void onPause(){foreground=false;if(video!=null){rememberPosition();video.pause();}super.onPause();}
    @Override protected void onResume(){super.onResume();foreground=true;if(video!=null&&videoPrepared)video.start();}
    @Override protected void onDestroy(){generation++;if(pending!=null)pending.cancel(true);if(progress!=null){progress.dismiss();progress=null;}stopPlayer(true);workers.shutdownNow();ui.removeCallbacksAndMessages(null);super.onDestroy();}
}
