param(
    [string]$Sdk = "$env:LOCALAPPDATA\Android\Sdk",
    [string]$JavaRoot = "C:\Program Files\Android\Android Studio\jbr"
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$project = $PSScriptRoot
$sdkPlatform = Get-ChildItem -LiteralPath "$Sdk\platforms" -Directory |
    Where-Object { Test-Path (Join-Path $_.FullName 'android.jar') } |
    Sort-Object { [int]([regex]::Match($_.Name, '\d+').Value) } -Descending |
    Select-Object -First 1
$buildTools = Get-ChildItem -LiteralPath "$Sdk\build-tools" -Directory |
    Where-Object { $_.Name -match '^\d+\.\d+\.\d+$' } |
    Sort-Object { [version]$_.Name } -Descending | Select-Object -First 1
if (-not $sdkPlatform -or -not $buildTools) { throw 'Android SDK-Plattform oder Build Tools fehlen.' }
$androidJar = Join-Path $sdkPlatform.FullName 'android.jar'
$toolRoot = $buildTools.FullName
$javaBin = Join-Path $JavaRoot 'bin'
foreach ($name in @('java.exe','javac.exe','jar.exe','keytool.exe')) {
    if (-not (Test-Path (Join-Path $javaBin $name))) { throw "Java-Werkzeug fehlt: $name" }
}
foreach ($name in @('aapt2.exe','d8.bat','zipalign.exe','apksigner.bat')) {
    if (-not (Test-Path (Join-Path $toolRoot $name))) { throw "SDK-Werkzeug fehlt: $name" }
}
function Invoke-Checked {
    param([string]$Exe, [string[]]$Arguments)
    & $Exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Build abgebrochen: $([IO.Path]::GetFileName($Exe)) (Exit $LASTEXITCODE)" }
}
$previousJavaHome = $env:JAVA_HOME
$previousPath = $env:PATH
try {
    $env:JAVA_HOME = $JavaRoot
    $env:PATH = "$javaBin;$previousPath"
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    # Jeder Build in einem eigenen Verzeichnis; vorhandene Dateien bleiben erhalten.
    $build = Join-Path $project "build\$stamp"
    $classes = Join-Path $build 'classes'
    $generated = Join-Path $build 'generated'
    $dex = Join-Path $build 'dex'
    foreach ($folder in @($build,$classes,$generated,$dex,"$project\output","$project\.local")) {
        New-Item -ItemType Directory -Force -Path $folder | Out-Null
    }
    Write-Host "SDK: $($sdkPlatform.Name) | Build Tools: $($buildTools.Name)" -ForegroundColor Cyan
    Invoke-Checked -Exe "$toolRoot\aapt2.exe" -Arguments @('compile','--dir',"$project\res",'-o',"$build\resources.zip")
    Invoke-Checked -Exe "$toolRoot\aapt2.exe" -Arguments @('link','-o',"$build\unsigned.apk",'-I',$androidJar,'--manifest',"$project\AndroidManifest.xml",'--java',$generated,'-A',"$project\assets",'-R',"$build\resources.zip",'--auto-add-overlay')
    $javaFiles = @(Get-ChildItem -Path "$project\src","$generated" -Filter '*.java' -Recurse -File)
    $compilerArgs = @('--release','8','-encoding','UTF-8','-classpath',$androidJar,'-d',$classes) + @($javaFiles.FullName)
    # Argumentdatei vermeidet Windows-Längenlimits und erhält Pfade mit Leerzeichen.
    $argLines = @($compilerArgs | ForEach-Object { '"' + ($_.Replace('\','/').Replace('"','\"')) + '"' })
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllLines("$build\javac.args",$argLines,$utf8)
    Invoke-Checked -Exe "$javaBin\javac.exe" -Arguments @("@$build\javac.args")
    Invoke-Checked -Exe "$javaBin\jar.exe" -Arguments @('--create','--file',"$build\classes.jar",'-C',$classes,'.')
    Invoke-Checked -Exe "$toolRoot\d8.bat" -Arguments @('--lib',$androidJar,'--min-api','26','--output',$dex,"$build\classes.jar")
    foreach ($dexFile in @(Get-ChildItem -LiteralPath $dex -Filter '*.dex' -File)) {
        Invoke-Checked -Exe "$javaBin\jar.exe" -Arguments @('uf',"$build\unsigned.apk",'-C',$dex,$dexFile.Name)
    }
    Invoke-Checked -Exe "$toolRoot\zipalign.exe" -Arguments @('-f','4',"$build\unsigned.apk","$build\aligned.apk")
    $key = Join-Path $project '.local\debug.keystore'
    if (-not (Test-Path -LiteralPath $key)) {
        Invoke-Checked -Exe "$javaBin\keytool.exe" -Arguments @('-genkeypair','-keystore',$key,'-storepass','android','-keypass','android','-alias','androiddebugkey','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=GTIPTV Android Development,O=Development,C=DE')
    }
    $apk = Join-Path $project 'output\GTIPTV-Android-0.1.1-tvtest.apk'
    Invoke-Checked -Exe "$toolRoot\apksigner.bat" -Arguments @('sign','--ks',$key,'--ks-pass','pass:android','--key-pass','pass:android','--ks-key-alias','androiddebugkey','--out',$apk,"$build\aligned.apk")
    Invoke-Checked -Exe "$toolRoot\apksigner.bat" -Arguments @('verify','--verbose',$apk)
    Write-Host "`nAPK erstellt und Signatur geprüft: $apk" -ForegroundColor Green
    Get-FileHash -LiteralPath $apk -Algorithm SHA256 | Format-List
} finally {
    $env:JAVA_HOME = $previousJavaHome
    $env:PATH = $previousPath
}
