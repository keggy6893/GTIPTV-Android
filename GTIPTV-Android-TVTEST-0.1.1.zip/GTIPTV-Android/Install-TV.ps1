param(
    [string]$Device = '',
    [string]$Sdk = "$env:LOCALAPPDATA\Android\Sdk"
)
$ErrorActionPreference = 'Stop'
$adb = Join-Path $Sdk 'platform-tools\adb.exe'
$apk = Join-Path $PSScriptRoot 'output\GTIPTV-Android-0.1.1-tvtest.apk'
if (-not (Test-Path -LiteralPath $adb)) { throw 'ADB wurde nicht gefunden.' }
if (-not (Test-Path -LiteralPath $apk)) { throw 'APK fehlt. Bitte zuerst Build.ps1 ausführen.' }
if ($Device) {
    & $adb connect $Device
    if ($LASTEXITCODE -ne 0) { throw 'ADB-Verbindung fehlgeschlagen.' }
} else {
    $inventory = @(& $adb devices)
    if ($LASTEXITCODE -ne 0) { throw 'ADB-Geräteliste konnte nicht gelesen werden.' }
    $televisions = @()
    foreach ($line in $inventory) {
        if ($line -match '^(\S+)\s+device\s*$') {
            $candidate = $Matches[1]
            $features = @(& $adb -s $candidate shell pm list features)
            if ($LASTEXITCODE -eq 0 -and ($features -match 'android\.software\.leanback')) {
                $televisions += $candidate
            }
        }
    }
    if ($televisions.Count -ne 1) {
        & $adb devices -l
        throw 'Kein eindeutig verbundener Android-TV. Bitte die aktuelle TV-ADB-Adresse mit -Device angeben.'
    }
    $Device = $televisions[0]
    Write-Host "Verbundener Android-TV: $Device" -ForegroundColor Cyan
}
& $adb -s $Device get-state
if ($LASTEXITCODE -ne 0) { throw 'TV nicht verbunden oder noch nicht autorisiert. Freigabe am TV prüfen.' }
& $adb -s $Device install -r $apk
if ($LASTEXITCODE -ne 0) { throw 'Installation fehlgeschlagen. Keine bestehende App wurde automatisch deinstalliert.' }
& $adb -s $Device shell am start -n de.gtiptv.android/.MainActivity
if ($LASTEXITCODE -ne 0) { throw 'App installiert, Start fehlgeschlagen.' }
