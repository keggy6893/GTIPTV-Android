// SPDX-License-Identifier: GPL-2.0-or-later
// Android implementation, 2026. Original design: Copyright (C) 2026 VicTuS59.
package de.gtiptv.android;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class Catalog {
    static final class Source {
        String id = UUID.randomUUID().toString(), name = "", type = "xtream", server = "", user = "", password = "";
        JSONObject json() throws Exception {
            return new JSONObject().put("id",id).put("name",name).put("type",type).put("server",server).put("user",user).put("password",password);
        }
        static Source from(JSONObject o) {
            Source s = new Source(); s.id=o.optString("id",s.id); s.name=o.optString("name"); s.type=o.optString("type","xtream");
            s.server=o.optString("server"); s.user=o.optString("user"); s.password=o.optString("password"); return s;
        }
    }
    static final class Item {
        String id="", name="", kind="", category="", url="", extension="mp4", source="", description="";
        JSONObject json() throws Exception {
            return new JSONObject().put("id",id).put("name",name).put("kind",kind).put("category",category).put("url",url)
                .put("extension",extension).put("source",source).put("description",description);
        }
        static Item from(JSONObject o) {
            Item i=new Item(); i.id=o.optString("id");i.name=o.optString("name");i.kind=o.optString("kind");i.category=o.optString("category");
            i.url=o.optString("url");i.extension=o.optString("extension","mp4");i.source=o.optString("source");i.description=o.optString("description");return i;
        }
        String key() { return source+":"+kind+":"+id; }
    }
    interface Progress { void report(String message); }
    static String encode(String s) throws Exception { return URLEncoder.encode(s,"UTF-8").replace("+","%20"); }
    static String normalize(String raw) throws Exception {
        String value=raw.trim(); URL u=new URL(value);
        if (!u.getProtocol().equals("http") && !u.getProtocol().equals("https")) throw new Exception("protocol");
        if (u.getHost().isEmpty() || u.getUserInfo()!=null) throw new Exception("address");
        while(value.endsWith("/")) value=value.substring(0,value.length()-1);
        if (value.endsWith("/player_api.php")) value=value.substring(0,value.length()-15);
        return value;
    }
    static String get(String address) throws Exception {
        HttpURLConnection c=null;
        try {
            URL requested = new URL(address);
            for(int redirects=0; redirects<6; redirects++) {
                if(!requested.getProtocol().equals("https") && !requested.getProtocol().equals("http")) throw new Exception("protocol");
                c=(HttpURLConnection)requested.openConnection(); c.setConnectTimeout(12000);c.setReadTimeout(25000);
                c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","GT-IPTV-Android/0.1.1");
                int code=c.getResponseCode();
                if(code>=300 && code<400) {
                    String location=c.getHeaderField("Location"); if(location==null) throw new Exception("redirect");
                    URL next=new URL(requested,location);
                    if(requested.getProtocol().equals("https") && !next.getProtocol().equals("https")) throw new Exception("downgrade");
                    c.disconnect();c=null;requested=next;continue;
                }
                if(code<200 || code>=300) throw new Exception("HTTP "+code);
                try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                    byte[] b=new byte[16384]; int n;
                    while((n=in.read(b))!=-1) {
                        if(Thread.currentThread().isInterrupted()) throw new Exception("cancelled");
                        if(out.size()+n>64*1024*1024) throw new Exception("too large");
                        out.write(b,0,n);
                    }
                    return new String(out.toByteArray(),"UTF-8").replace("\uFEFF","");
                }
            }
            throw new Exception("redirect limit");
        } finally { if(c!=null)c.disconnect(); }
    }
    static String api(Source s,String action,String extra) throws Exception {
        String url=s.server+"/player_api.php?username="+encode(s.user)+"&password="+encode(s.password);
        if(!action.isEmpty())url+="&action="+action;
        return get(url+extra);
    }
    static JSONObject check(Source s) throws Exception {
        JSONObject o=new JSONObject(api(s,"",""));JSONObject user=o.optJSONObject("user_info");
        if(user==null || !user.optString("auth").equals("1"))throw new Exception("auth");
        if(!user.optString("status","Active").equalsIgnoreCase("Active"))throw new Exception("inactive");
        return user;
    }
    static LinkedHashMap<String,String> categories(Source s,String kind) throws Exception {
        String prefix=kind.equals("movie")?"vod":kind;
        JSONArray a=new JSONArray(api(s,"get_"+prefix+"_categories",""));
        LinkedHashMap<String,String> result=new LinkedHashMap<>();result.put("","Alle");
        for(int n=0;n<a.length();n++){JSONObject o=a.getJSONObject(n);result.put(o.optString("category_id"),o.optString("category_name","Ohne Kategorie"));}
        return result;
    }
    static List<Item> items(Source s,String kind,String category) throws Exception {
        String action=kind.equals("movie")?"get_vod_streams":kind.equals("series")?"get_series":"get_live_streams";
        String extra=category.isEmpty()?"":"&category_id="+encode(category);
        JSONArray a=new JSONArray(api(s,action,extra));List<Item> result=new ArrayList<>();
        for(int n=0;n<a.length();n++){
            JSONObject o=a.getJSONObject(n);Item i=new Item();i.source=s.id;i.kind=kind;
            i.id=o.optString(kind.equals("series")?"series_id":"stream_id");i.name=o.optString("name","Ohne Titel");
            i.category=o.optString("category_id");i.extension=o.optString("container_extension","mp4");i.description=o.optString("plot");
            if(!i.id.isEmpty())result.add(i);
        }return result;
    }
    static List<Item> episodes(Source s,Item series) throws Exception {
        JSONObject root=new JSONObject(api(s,"get_series_info","&series_id="+encode(series.id)));
        JSONObject ep=root.optJSONObject("episodes");List<Item> result=new ArrayList<>();if(ep==null)return result;
        List<String> keys=new ArrayList<>();java.util.Iterator<String> it=ep.keys();while(it.hasNext())keys.add(it.next());
        java.util.Collections.sort(keys,(a,b)->Integer.compare(integer(a),integer(b)));
        for(String season:keys){JSONArray arr=ep.optJSONArray(season);if(arr==null)continue;
            for(int n=0;n<arr.length();n++){JSONObject o=arr.getJSONObject(n);Item i=new Item();i.source=s.id;i.kind="episode";
                i.id=o.optString("id");i.extension=o.optString("container_extension","mp4");i.category=season;
                i.name="S"+season+" · E"+o.optString("episode_num",String.valueOf(n+1))+"   "+o.optString("title",series.name);
                JSONObject info=o.optJSONObject("info");if(info!=null)i.description=info.optString("plot");
                if(!i.id.isEmpty())result.add(i);
            }
        }return result;
    }
    private static int integer(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    static String stream(Source s,Item i) throws Exception {
        if(!i.url.isEmpty())return i.url;
        String prefix=i.kind.equals("live")?"live":i.kind.equals("movie")?"movie":"series";
        String ext=i.kind.equals("live")?"m3u8":i.extension;
        if(!ext.matches("[a-zA-Z0-9]{1,12}"))ext="mp4";
        return s.server+"/"+prefix+"/"+encode(s.user)+"/"+encode(s.password)+"/"+encode(i.id)+"."+ext;
    }
    static List<Item> m3u(Source s) throws Exception { return parseM3u(s,get(s.server)); }
    static List<Item> parseM3u(Source s,String body) throws Exception {
        if(!body.trim().startsWith("#EXTM3U"))throw new Exception("Not M3U");
        List<Item> result=new ArrayList<>();String name="",group="Ohne Kategorie";
        Pattern groupPattern=Pattern.compile("group-title=\"([^\"]*)\"");
        for(String line:body.split("\\r?\\n")){
            line=line.trim();if(line.isEmpty())continue;
            if(line.startsWith("#EXTINF:")){
                boolean quoted=false;int comma=-1;
                for(int n=0;n<line.length();n++){char ch=line.charAt(n);if(ch=='\"')quoted=!quoted;else if(ch==','&&!quoted){comma=n;break;}}
                name=comma>=0?line.substring(comma+1).trim():"Sender";Matcher m=groupPattern.matcher(line);group=m.find()?m.group(1):"Ohne Kategorie";
            }else if(!line.startsWith("#")){
                URL url=new URL(new URL(s.server),line);
                if(!url.getProtocol().equals("http")&&!url.getProtocol().equals("https"))continue;
                Item i=new Item();i.kind="live";i.source=s.id;i.name=name.isEmpty()?"Sender "+(result.size()+1):name;
                i.url=url.toString();i.id=UUID.nameUUIDFromBytes(i.url.getBytes("UTF-8")).toString();i.category=group;result.add(i);name="";
            }
        }if(result.isEmpty())throw new Exception("Empty playlist");return result;
    }
    static String epg(Source s,Item item) throws Exception {
        JSONObject root=new JSONObject(api(s,"get_short_epg","&stream_id="+encode(item.id)+"&limit=8"));
        JSONArray a=root.optJSONArray("epg_listings");if(a==null||a.length()==0)return "Keine EPG-Daten vom Anbieter erhalten.";
        StringBuilder out=new StringBuilder();
        for(int n=0;n<a.length();n++){JSONObject o=a.getJSONObject(n);out.append(o.optString("start")).append("\n")
            .append(decode(o.optString("title"))).append("\n").append(decode(o.optString("description"))).append("\n\n");}
        return out.toString();
    }
    static String decode(String s){try{return new String(android.util.Base64.decode(s,android.util.Base64.DEFAULT),"UTF-8");}catch(Exception e){return s;}}
}
