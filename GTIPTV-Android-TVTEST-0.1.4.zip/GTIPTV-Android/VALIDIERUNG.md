# Prüfstand Android-Test 0.1.3

Stand: 14.10.2026.

## Erzeugung und automatisierte Prüfungen

- Java-Produktionsquellen gegen Android API 35 ohne Compilerfehler kompiliert.
- Ressourcen/Manifest mit Android SDK Build Tools 36.0.0 verarbeitet.
- DEX mit minSdk 26 erstellt; targetSdk 34, versionCode 4.
- APK-Ausrichtung und Signaturen v2/v3 erfolgreich geprüft.
- Derselbe Entwicklungsschlüssel wie bei 0.1.0 und 0.1.1 verwendet.
- Originalgrafiken einschließlich der r89-Live-Hintergründe unverändert übernommen.
- 19 Katalog-/Netzwerktests mit synthetischen Quellen bestanden.
- 11 EPG-/Kompatibilitätsprüfungen bestanden: Epochenwerte in Sekunden/Millisekunden,
  aktuelle/nächste Sendung an Zeitgrenzen, unbekannte Intervalle, Logo-Persistenz
  und Lesen älterer Favoriten ohne Logo-Feld.
- Keine echten IPTV-Zugangsdaten oder Provider für Host-Tests verwendet.

## Von der Nutzerin am TCL gezeigt/gemeldet

- 0.1.0: Einstieg startet; Kategorien und 20 Sender in Oeffentliche werden geladen.
- 0.1.1: Neue Kategorienansicht mit acht Zeilen und 34 Kategorien sichtbar.
- Live-TV-Wiedergabe: kein Bild und kein Ton. Reparatur auf Nutzerwunsch am Schluss.

## Änderung 0.1.2 und offene Prüfung

Dreispaltige Senderliste nach Receiver-Screenshot: großes Logo und Jetzt-Bereich
links; zehn Sender, Logos, Sendungen und Fortschritt mittig; schwarzes Vorschaufeld
und Folgesendungen rechts. Pfeiltasten/Seitennavigation, Favorit und Aktualisieren.
Richtige r89-Hintergrundvarianten und dunkle Auswahlfarbe auch für Kategorien.

Die neue Ansicht, Anbieterlogos und echte EPG-Antworten sind noch nicht auf dem
TCL geprüft. Ohne verwertbare EPG-Daten werden keine Sendungen oder Prozentwerte
erfunden. Das Vorschaubild bleibt schwarz; der Player wurde nicht repariert.
Wetter bleibt ein Platzhalter. Keine vollständige 1:1-Portierung.

## Änderung 0.1.3

Cinematic-Filmansicht nach Receiver-Screenshot: Kategorien, Metadaten und
Hintergrundbild, fünf Poster, Favoriten, Sortierung und kategorienspezifische
Suche. Providerdaten statt erfundener Titel/Bilder. Rückkehr erhält Auswahl.
39 synthetische Tests bestanden (19 Katalog, 11 EPG, 9 Film-Metadaten).
Der 0.1.2-TCL-Screenshot zeigt Senderlogos und EPG in der neuen Senderliste;
Nutzerin meldet Ton, aber kein Bild. Wiedergabereparatur bleibt zurückgestellt.
Die neue Filmansicht ist noch nicht am TCL geprüft. Downloads sind nicht portiert.


## 0.1.4: Player-OSD
- Eigene transparente Infoleiste nach VU-Referenz ersetzt Android MediaController.
- OK zeigt die Leiste; bei sichtbarer Leiste Pause/Fortsetzen. INFO/MENU blendet ein.
- Filme: links/rechts +/-10 Sekunden; Live-TV ohne künstliche Zeitachse.
- Poster/Logo und Live-EPG asynchron; keine erfundenen technischen Werte.
- HLS unverändert, TS-Test nicht übernommen. RTL durch Nutzerin unter 0.1.3 mit Bild/Ton bestätigt.
- Java-Kompilation geprüft. Darstellung und Fernbedienung von 0.1.4 am TCL noch zu prüfen.
