package de.gtiptv.android;
import org.json.JSONObject;

/** Boundary checks for provider timestamps and EPG intervals, with synthetic data. */
public final class GuideChecks {
    private static int count=0;
    private static void check(boolean value,String label){if(!value)throw new AssertionError(label);count++;}
    public static void main(String[] args) throws Exception {
        GuideData.Program p=new GuideData.Program();p.start=100;p.end=200;
        check(p.percent(150)==50,"mid-program progress");
        check(p.percent(50)==0&&p.percent(300)==100,"clamp progress outside interval");
        GuideData.Schedule schedule=new GuideData.Schedule();schedule.programs.add(p);
        check(schedule.now(100)==p,"start boundary belongs to current program");
        check(schedule.now(200)==null,"end boundary belongs to next program");
        check(schedule.next(99).size()==1&&schedule.next(100).isEmpty(),"exclude already-started programs from next");
        check(GuideData.timestamp(new JSONObject().put("start_timestamp",1700000000),"start_timestamp","start")==1700000000000L,"seconds epoch");
        check(GuideData.timestamp(new JSONObject().put("start_timestamp",1700000000000L),"start_timestamp","start")==1700000000000L,"milliseconds epoch");
        check(GuideData.timestamp(new JSONObject().put("start","bad date"),"start_timestamp","start")==0,"invalid timestamp remains unknown");
        p.end=p.start;check(p.percent(150)==-1,"invalid interval has no fabricated percentage");
        Catalog.Item item=new Catalog.Item();item.icon="https://example.invalid/logo.png";
        check(Catalog.Item.from(item.json()).icon.equals(item.icon),"logo survives favorites serialization");
        check(Catalog.Item.from(new JSONObject().put("id","old")).icon.isEmpty(),"old favorites without icon remain readable");
        System.out.println("PASS: "+count+" guide and compatibility checks");
    }
}
