package de.gtiptv.android;
import org.json.JSONArray;
import org.json.JSONObject;

public final class MovieChecks {
    private static int count=0;
    private static void check(boolean value,String name){if(!value)throw new AssertionError(name);count++;}
    public static void main(String[] args) throws Exception {
        Catalog.Item item=new Catalog.Item();item.name="List title";item.icon="https://example.invalid/poster.jpg";item.description="List description";
        JSONObject info=new JSONObject().put("name","Detail title").put("releasedate","2026-09-01").put("duration_secs",6216)
            .put("backdrop_path",new JSONArray().put("not-a-url").put("https://example.invalid/backdrop.jpg"));
        MovieData details=MovieData.parse(new JSONObject().put("info",info),item);
        check(details.title.equals("Detail title"),"provider detail title");
        check(details.year.equals("2026"),"release date year");
        check(details.duration.equals("01:43:36"),"duration seconds");
        check(details.backdrop.equals("https://example.invalid/backdrop.jpg"),"first valid backdrop URL");
        check(details.poster.equals(item.icon)&&details.plot.equals(item.description),"list fallback fields");
        MovieData missing=MovieData.fallback(item);
        check(missing.year.isEmpty()&&missing.rating.isEmpty()&&missing.genre.isEmpty(),"missing metadata remains unknown");
        check(missing.title.equals("List title"),"missing info object keeps list title");
        check(MovieData.parse(new JSONObject().put("info",new JSONObject().put("backdrop_path","file:///private")),item).backdrop.isEmpty(),"reject local backdrop path");
        check(MovieData.parse(new JSONObject().put("info",new JSONObject().put("duration","02:03:04").put("duration_secs",1)),item).duration.equals("02:03:04"),"explicit provider duration wins");
        System.out.println("PASS: "+count+" movie metadata checks");
    }
}
