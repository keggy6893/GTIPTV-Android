// SPDX-License-Identifier: GPL-2.0-or-later
// Cinematic layout/artwork: Copyright (C) 2026 VicTuS59. Android adaptation: 2026.
package de.gtiptv.android;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

final class MovieBrowserView extends View {
    interface Actions {
        void play(Catalog.Item item);
        void favorite(Catalog.Item item);
        boolean isFavorite(Catalog.Item item);
        void back();
    }
    static final class State {
        String category="";int selected=0;boolean sidebar=true;
        List<Catalog.Item> items=new ArrayList<>(),unfiltered=new ArrayList<>();String query="";boolean loaded=false;
    }
    private static final LruCache<String,Bitmap> IMAGES=new LruCache<String,Bitmap>(28*1024*1024){
        @Override protected int sizeOf(String key,Bitmap image){return image.getByteCount();}
    };
    private static final LruCache<String,MovieData> DETAILS=new LruCache<>(80);
    private final Context context;
    private final Catalog.Source source;
    private final LinkedHashMap<String,String> categories;
    private final List<String> categoryIds;
    private final ExecutorService workers;
    private final Actions actions;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final Map<String,Bitmap> art=new HashMap<>();
    private final Set<String> requests=new HashSet<>();
    private final List<Future<?>> jobs=new ArrayList<>();
    private List<Catalog.Item> movies=new ArrayList<>(),unfiltered=new ArrayList<>();
    private int category=0,selected=0,categoryGeneration=0;
    private boolean sidebar=true,closed=false,loaded=false;
    private String status="Filme werden geladen …",query="";
    private float scale=1,ox=0,oy=0;
    private Runnable pendingCategory,pendingDetails;

    MovieBrowserView(Context context,Catalog.Source source,LinkedHashMap<String,String> categories,ExecutorService workers,Actions actions,State initial){
        super(context);this.context=context;this.source=source;this.categories=new LinkedHashMap<>(categories);this.categories.put("","Alle Filme");
        categoryIds=new ArrayList<>(this.categories.keySet());this.workers=workers;this.actions=actions;
        if(initial!=null){category=Math.max(0,categoryIds.indexOf(initial.category));selected=Math.max(0,initial.selected);sidebar=initial.sidebar;movies=new ArrayList<>(initial.items);unfiltered=new ArrayList<>(initial.unfiltered);loaded=initial.loaded;query=initial.query;}
        setFocusable(true);setFocusableInTouchMode(true);setBackgroundColor(0xff050914);
        for(String name:new String[]{"screen-cinematic-glass-r90-1080.png","cinematic-scrim-r112.png","favorite-star-v15.png","remote-key-cyan-v42.png","remote-key-red-v42.png","remote-key-green-v42.png","remote-key-yellow-v42.png","remote-key-blue-v42.png","remote-key-neutral-v42.png"}){
            try(InputStream in=context.getAssets().open("art/"+name)){Bitmap image=BitmapFactory.decodeStream(in);if(image!=null)art.put(name,image);}catch(Exception ignored){}
        }
    }
    State state(){State state=new State();state.category=categoryIds.get(category);state.selected=selected;state.sidebar=sidebar;state.items=new ArrayList<>(movies);state.unfiltered=new ArrayList<>(unfiltered);state.query=query;state.loaded=loaded;return state;}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();closed=false;if(loaded){status=movies.isEmpty()?"Keine Filme vorhanden":"";loadPosters();}else scheduleCategory(0);}
    @Override protected void onDetachedFromWindow(){closed=true;ui.removeCallbacksAndMessages(null);for(Future<?> job:jobs)job.cancel(true);jobs.clear();super.onDetachedFromWindow();}
    private void scheduleCategory(int delay){
        categoryGeneration++;final int token=categoryGeneration;final String id=categoryIds.get(category);
        if(pendingCategory!=null)ui.removeCallbacks(pendingCategory);if(pendingDetails!=null)ui.removeCallbacks(pendingDetails);
        selected=0;loaded=false;movies.clear();unfiltered.clear();status="Filme werden geladen …";query="";invalidate();
        pendingCategory=()->jobs.add(workers.submit(()->{
            try{List<Catalog.Item> result=Catalog.items(source,"movie",id);ui.post(()->{if(closed||token!=categoryGeneration)return;movies=new ArrayList<>(result);unfiltered=new ArrayList<>(result);loaded=true;status=movies.isEmpty()?"Keine Filme in dieser Kategorie":"";loadPosters();});}
            catch(Exception e){ui.post(()->{if(!closed&&token==categoryGeneration){status="Filme konnten nicht geladen werden. Grün: Erneut versuchen.";invalidate();}});}
        }));ui.postDelayed(pendingCategory,delay);
    }
    private Catalog.Item current(){return movies.isEmpty()?null:movies.get(Math.max(0,Math.min(selected,movies.size()-1)));}
    private void loadPosters(){
        Catalog.Item current=current();if(current!=null){loadImage(current.icon,768);scheduleDetails();}
        int page=(selected/5)*5;for(int n=page;n<Math.min(page+5,movies.size());n++)loadImage(movies.get(n).icon,768);
        setContentDescription("Filme. Kategorie "+categories.get(categoryIds.get(category))+". "+(current==null?status:current.name)+". Pfeil rechts zu den Postern, OK Wiedergabe, Blau Suche, Rot Favorit.");invalidate();
    }
    private void scheduleDetails(){
        if(pendingDetails!=null)ui.removeCallbacks(pendingDetails);Catalog.Item item=current();if(item==null)return;
        MovieData cached=DETAILS.get(item.key());if(cached!=null){loadImage(cached.backdrop,1920);loadImage(cached.poster,768);return;}
        pendingDetails=()->{if(!requests.add("details:"+item.key()))return;jobs.add(workers.submit(()->{
            MovieData details;try{details=MovieData.load(source,item);}catch(Exception e){details=MovieData.fallback(item);}
            MovieData result=details;DETAILS.put(item.key(),details);ui.post(()->{requests.remove("details:"+item.key());if(closed)return;Catalog.Item active=current();if(active!=null&&active.key().equals(item.key())){loadImage(result.backdrop,1920);loadImage(result.poster,768);invalidate();}});
        }));};ui.postDelayed(pendingDetails,220);
    }
    private void loadImage(String url,int max){
        if(url==null||url.isEmpty()||url.equals("null")||IMAGES.get(url)!=null||!requests.add("image:"+url))return;
        jobs.add(workers.submit(()->{try{Bitmap image=GuideData.image(url,max);if(image!=null)IMAGES.put(url,image);}catch(Exception ignored){}ui.post(()->{if(!closed)invalidate();});}));
    }
    private void fill(Canvas c,float x,float y,float w,float h,int color){paint.setStyle(Paint.Style.FILL);paint.setColor(color);c.drawRect(x,y,x+w,y+h,paint);}
    private void text(Canvas c,String value,float x,float y,float w,float h,float font,int color,boolean center){
        paint.setTextSize(font);paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));paint.setColor(color);paint.setStyle(Paint.Style.FILL);
        String string=TextUtils.ellipsize(value==null?"":value,new TextPaint(paint),Math.max(1,w),TextUtils.TruncateAt.END).toString();Paint.FontMetrics fm=paint.getFontMetrics();
        c.save();c.clipRect(x,y,x+w,y+h);c.drawText(string,center?x+(w-paint.measureText(string))/2:x,y+h/2-(fm.ascent+fm.descent)/2,paint);c.restore();
    }
    private void picture(Canvas c,Bitmap bitmap,float x,float y,float w,float h,boolean cover){
        if(bitmap==null||bitmap.isRecycled())return;float s=cover?Math.max(w/bitmap.getWidth(),h/bitmap.getHeight()):Math.min(w/bitmap.getWidth(),h/bitmap.getHeight());
        float iw=bitmap.getWidth()*s,ih=bitmap.getHeight()*s;c.save();c.clipRect(x,y,x+w,y+h);paint.setColor(Color.WHITE);c.drawBitmap(bitmap,null,new RectF(x+(w-iw)/2,y+(h-ih)/2,x+(w+iw)/2,y+(h+ih)/2),paint);c.restore();
    }
    private void stretch(Canvas c,Bitmap bitmap,float x,float y,float w,float h){if(bitmap!=null){paint.setColor(Color.WHITE);c.drawBitmap(bitmap,null,new RectF(x,y,x+w,y+h),paint);}}
    private void outline(Canvas c,float x,float y,float w,float h,int color,float width){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(width);paint.setColor(color);c.drawRect(x,y,x+w,y+h,paint);paint.setStyle(Paint.Style.FILL);}
    private void paragraph(Canvas c,String value,float x,float y,float w,float h,int font,int color,int lines){
        TextPaint tp=new TextPaint(Paint.ANTI_ALIAS_FLAG);tp.setColor(color);tp.setTextSize(font);
        android.text.StaticLayout layout=android.text.StaticLayout.Builder.obtain(value,0,value.length(),tp,(int)w).setMaxLines(lines).setEllipsize(TextUtils.TruncateAt.END).build();c.save();c.clipRect(x,y,x+w,y+h);c.translate(x,y);layout.draw(c);c.restore();
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);scale=Math.min(getWidth()/1920f,getHeight()/1080f);ox=(getWidth()-1920*scale)/2;oy=(getHeight()-1080*scale)/2;c.save();c.translate(ox,oy);c.scale(scale,scale);
        stretch(c,art.get("screen-cinematic-glass-r90-1080.png"),0,0,1920,1080);
        Catalog.Item item=current();MovieData details=item==null?null:DETAILS.get(item.key());if(details==null&&item!=null)details=MovieData.fallback(item);
        if(details!=null){Bitmap hero=IMAGES.get(details.backdrop);if(hero!=null)picture(c,hero,365,0,1555,616,true);}
        stretch(c,art.get("cinematic-scrim-r112.png"),365,0,1555,616);
        fill(c,0,4,365,4,0xff22d3ee);text(c,"FILMKATEGORIEN",32,12,300,40,21,0xff22d3ee,false);
        int catPage=(category/12)*12;
        for(int slot=0;slot<12;slot++){int n=catPage+slot;if(n>=categoryIds.size())break;int y=58+slot*72;
            if(n==category){fill(c,22,y,320,64,sidebar?0xff14375e:0xb014375e);fill(c,22,y,5,64,0xff2f75c9);}
            text(c,categories.get(categoryIds.get(n)),42,y,290,64,21,0xfff8fafc,false);
        }
        fill(c,342,58,8,856,0xff26344e);int thumb=Math.max(32,856*Math.min(12,categoryIds.size())/Math.max(1,categoryIds.size()));
        float pos=categoryIds.size()<=12?0:Math.min(1,catPage/(float)(categoryIds.size()-12));fill(c,342,58+(856-thumb)*pos,8,thumb,0xff22d3ee);
        text(c,"Kategorien: "+categoryIds.size()+" · "+(category+1)+"/"+categoryIds.size(),24,920,316,38,17,0xff9aa8be,true);
        if(details!=null){
            text(c,details.title,403,50,454,72,38,Color.WHITE,false);
            text(c,"★ "+(details.rating.isEmpty()?"--":details.rating),403,132,145,42,25,0xfff2c629,false);fill(c,553,140,3,26,0xff22d3ee);
            text(c,(details.year.isEmpty()?"--":details.year)+"  |  "+(details.duration.isEmpty()?"--:--:--":details.duration),578,132,360,42,22,Color.WHITE,false);
            text(c,details.genre,403,176,454,38,21,0xff22d3ee,false);fill(c,403,214,454,3,0xff164b60);
            text(c,"FILMZUSAMMENFASSUNG",403,222,454,38,21,0xfff2c629,false);
            paragraph(c,details.plot.isEmpty()?"Keine Beschreibung vom Anbieter erhalten.":details.plot,403,266,454,220,22,Color.WHITE,9);
            fill(c,365,507,1555,40,0xa0050914);
            String people=(details.director.isEmpty()?"":"Regie: "+details.director)+(details.cast.isEmpty()?"":(details.director.isEmpty()?"":"  |  ")+"Besetzung: "+details.cast);
            text(c,people,397,500,1491,54,18,0xffe2e8f0,false);
        }else text(c,status,403,60,1300,72,34,Color.WHITE,false);
        text(c,categories.get(categoryIds.get(category)).toUpperCase(Locale.GERMANY)+" • "+movies.size()+" FILME"+(query.isEmpty()?"":" · SUCHE: "+query),365,574,1500,42,21,0xff22d3ee,false);
        if(!status.isEmpty()&&movies.isEmpty())text(c,status,400,700,1460,100,28,0xffc8d2e3,true);
        int page=(selected/5)*5;
        for(int slot=0;slot<5;slot++){
            int n=page+slot;if(n>=movies.size())break;Catalog.Item movie=movies.get(n);int x=365+slot*314;
            fill(c,x+6,622,284,332,0xff06111e);outline(c,x+2,618,292,340,n==selected&&!sidebar?0xff58a6ff:0xff17344d,n==selected&&!sidebar?4:2);
            fill(c,x+10,626,276,276,Color.BLACK);String poster=movie.icon;MovieData d=DETAILS.get(movie.key());if(d!=null&&!d.poster.isEmpty())poster=d.poster;
            picture(c,IMAGES.get(poster),x+10,626,276,276,false);
            paragraph(c,movie.name,x+16,913,264,42,18,0xfff8fafc,2);
            if(actions.isFavorite(movie))picture(c,art.get("favorite-star-v15.png"),x+250,634,26,26,false);
        }
        fill(c,365,962,1555,6,0xff26344e);if(!movies.isEmpty())fill(c,365+1555f*page/movies.size(),962,Math.max(24,1555f*Math.min(5,movies.size())/movies.size()),6,0xff22d3ee);
        String[] keys={"▲▼◀▶","CH±","OK","","","","","MENU","EXIT"};String[] captions={"Navigieren","Seite","Wiedergeben","Favorit","Aktualisieren","Bearbeiten","Suchen","Herunterladen","Zurück"};
        String[] colors={"cyan","cyan","cyan","red","green","yellow","blue","neutral","neutral"};int[] centers={168,381,578,772,966,1157,1354,1557,1758};
        for(int n=0;n<keys.length;n++){int center=centers[n];stretch(c,art.get("remote-key-"+colors[n]+"-v42.png"),center-38,993,76,31);text(c,keys[n],center-38,993,76,31,18,Color.WHITE,true);text(c,captions[n],center-105,1025,210,42,27,0xffc8d2e3,true);}
        c.restore();
    }
    private void moveMovie(int delta){if(movies.isEmpty())return;selected=Math.max(0,Math.min(movies.size()-1,selected+delta));loadPosters();}
    private void chooseCategory(int n){category=Math.floorMod(n,categoryIds.size());scheduleCategory(280);}
    private void favorite(){Catalog.Item item=current();if(item!=null){actions.favorite(item);invalidate();}}
    private void play(){Catalog.Item item=current();if(item!=null)actions.play(item);}
    private void refresh(){Catalog.Item item=current();if(item!=null)DETAILS.remove(item.key());scheduleCategory(0);}
    private void edit(){new AlertDialog.Builder(context).setTitle("Filmliste bearbeiten").setItems(new String[]{"Titel A–Z","Anbieterreihenfolge"},(d,n)->{
        movies=new ArrayList<>(unfiltered);if(n==0)Collections.sort(movies,(a,b)->a.name.compareToIgnoreCase(b.name));selected=0;query="";loadPosters();}).show();}
    private void search(){EditText input=new EditText(context);input.setSingleLine(true);input.setHint("Filmtitel in dieser Kategorie");
        new AlertDialog.Builder(context).setTitle("Filme suchen").setView(input).setPositiveButton("Suchen",(d,n)->{
            query=input.getText().toString().trim();String term=query.toLowerCase(Locale.ROOT);movies=new ArrayList<>();for(Catalog.Item item:unfiltered)if(item.name.toLowerCase(Locale.ROOT).contains(term))movies.add(item);selected=0;sidebar=false;status=movies.isEmpty()?"Keine passenden Filme gefunden":"";loadPosters();
        }).setNeutralButton("Alle anzeigen",(d,n)->{movies=new ArrayList<>(unfiltered);selected=0;query="";status="";loadPosters();}).setNegativeButton("Abbrechen",null).show();}
    private void download(){new AlertDialog.Builder(context).setTitle("Herunterladen").setMessage("Die Downloadfunktion der Receiver-Vorlage ist für Android noch nicht umgesetzt.").setPositiveButton("OK",null).show();}
    @Override public boolean onKeyDown(int key,KeyEvent event){switch(key){
        case KeyEvent.KEYCODE_DPAD_UP:if(sidebar)chooseCategory(category-1);else {sidebar=true;invalidate();}return true;
        case KeyEvent.KEYCODE_DPAD_DOWN:if(sidebar)chooseCategory(category+1);else moveMovie(5);return true;
        case KeyEvent.KEYCODE_DPAD_LEFT:if(sidebar)chooseCategory(category-12);else if(selected==0){sidebar=true;invalidate();}else moveMovie(-1);return true;
        case KeyEvent.KEYCODE_DPAD_RIGHT:if(sidebar){sidebar=false;loadPosters();}else moveMovie(1);return true;
        case KeyEvent.KEYCODE_DPAD_CENTER:case KeyEvent.KEYCODE_ENTER:if(sidebar){sidebar=false;loadPosters();}else play();return true;
        case KeyEvent.KEYCODE_CHANNEL_UP:case KeyEvent.KEYCODE_PAGE_UP:if(sidebar)chooseCategory(category-12);else moveMovie(-5);return true;
        case KeyEvent.KEYCODE_CHANNEL_DOWN:case KeyEvent.KEYCODE_PAGE_DOWN:if(sidebar)chooseCategory(category+12);else moveMovie(5);return true;
        case KeyEvent.KEYCODE_PROG_RED:favorite();return true;case KeyEvent.KEYCODE_PROG_GREEN:refresh();return true;
        case KeyEvent.KEYCODE_PROG_YELLOW:edit();return true;case KeyEvent.KEYCODE_PROG_BLUE:search();return true;case KeyEvent.KEYCODE_MENU:download();return true;
        default:return super.onKeyDown(key,event);
    }}
    @Override public boolean onTouchEvent(MotionEvent event){if(event.getAction()!=MotionEvent.ACTION_UP)return true;float x=(event.getX()-ox)/scale,y=(event.getY()-oy)/scale;
        if(x<365&&y>=58&&y<922){int n=(category/12)*12+(int)((y-58)/72);if(n<categoryIds.size()){sidebar=true;chooseCategory(n);}return true;}
        if(x>=365&&y>=616&&y<960){int n=(selected/5)*5+(int)((x-365)/314);if(n<movies.size()){selected=n;sidebar=false;loadPosters();}return true;}
        if(y>=990){int[] centers={168,381,578,772,966,1157,1354,1557,1758};int nearest=0;for(int n=1;n<centers.length;n++)if(Math.abs(x-centers[n])<Math.abs(x-centers[nearest]))nearest=n;
            switch(nearest){case 0:sidebar=!sidebar;invalidate();break;case 1:moveMovie(5);break;case 2:play();break;case 3:favorite();break;case 4:refresh();break;case 5:edit();break;case 6:search();break;case 7:download();break;case 8:actions.back();break;}}
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
