// SPDX-License-Identifier: GPL-2.0-or-later
package de.gtiptv.android;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

final class MovieData {
    String title="",year="",rating="",duration="",genre="",plot="",director="",cast="",poster="",backdrop="";
    static MovieData load(Catalog.Source source,Catalog.Item item) throws Exception {
        return parse(new JSONObject(Catalog.api(source,"get_vod_info","&vod_id="+Catalog.encode(item.id))),item);
    }
    static String value(JSONObject o,String key){String s=o.optString(key,"").trim();return s.equalsIgnoreCase("null")?"":s;}
    static MovieData parse(JSONObject root,Catalog.Item item){
        JSONObject info=root.optJSONObject("info");if(info==null)info=new JSONObject();JSONObject data=root.optJSONObject("movie_data");if(data==null)data=new JSONObject();
        MovieData d=new MovieData();d.title=value(info,"name");if(d.title.isEmpty())d.title=value(data,"name");if(d.title.isEmpty())d.title=item.name;
        d.plot=value(info,"plot");if(d.plot.isEmpty())d.plot=value(info,"description");if(d.plot.isEmpty())d.plot=item.description;
        d.poster=value(info,"movie_image");if(d.poster.isEmpty())d.poster=item.icon;
        String date=value(info,"releasedate");if(date.isEmpty())date=value(info,"release_date");if(date.isEmpty())date=value(info,"year");if(date.isEmpty())date=value(data,"year");
        if(date.matches("^\\d{4}.*"))d.year=date.substring(0,4);
        d.rating=value(info,"rating");if(d.rating.isEmpty())d.rating=value(data,"rating");
        d.duration=value(info,"duration");
        if(d.duration.isEmpty()){long seconds=info.optLong("duration_secs",0);if(seconds>0)d.duration=String.format(Locale.GERMANY,"%02d:%02d:%02d",seconds/3600,(seconds/60)%60,seconds%60);}
        d.genre=value(info,"genre");d.director=value(info,"director");d.cast=value(info,"cast");if(d.cast.isEmpty())d.cast=value(info,"actors");
        JSONArray backdrops=info.optJSONArray("backdrop_path");if(backdrops!=null){for(int n=0;n<backdrops.length();n++){String image=backdrops.optString(n,"");if(image.startsWith("https://")||image.startsWith("http://")){d.backdrop=image;break;}}}
        else {String image=value(info,"backdrop_path");if(image.startsWith("https://")||image.startsWith("http://"))d.backdrop=image;}
        return d;
    }
    static MovieData fallback(Catalog.Item item){return parse(new JSONObject(),item);}
}
