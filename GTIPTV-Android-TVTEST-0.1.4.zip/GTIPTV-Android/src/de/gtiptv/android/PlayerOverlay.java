// SPDX-License-Identifier: GPL-2.0-or-later
// Android implementation; original layout Copyright (C) 2026 VicTuS59.
package de.gtiptv.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaFormat;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.VideoView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Transparent OSD. Never owns or replaces the video surface. */
final class PlayerOverlay extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final VideoView video;
    private final Catalog.Item item;
    private final boolean live;
    private Bitmap poster;
    private GuideData.Schedule schedule;
    private String videoCodec="—",audioCodec="—",frameRate="—";
    private int width,height;
    private boolean prepared,shown=true,buffering=true;
    private long hideAt=SystemClock.uptimeMillis()+6500;
    private final Runnable tick=new Runnable(){public void run(){
        if(prepared&&shown&&SystemClock.uptimeMillis()>hideAt&&isRunning()){shown=false;}
        invalidate();handler.postDelayed(this,500);
    }};
    PlayerOverlay(Context context,VideoView view,Catalog.Item entry){
        super(context);video=view;item=entry;live="live".equals(item.kind);
        setFocusable(true);setFocusableInTouchMode(true);setWillNotDraw(false);
        setContentDescription("Player: OK Info und Pause, links rechts spulen, Zurück beenden");
    }
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();handler.post(tick);}
    @Override protected void onDetachedFromWindow(){handler.removeCallbacksAndMessages(null);poster=null;super.onDetachedFromWindow();}
    void poster(Bitmap image){poster=image;invalidate();}
    void schedule(GuideData.Schedule value){schedule=value;invalidate();}
    void buffering(boolean value){buffering=value;invalidate();}
    void dimensions(int w,int h){width=w;height=h;invalidate();}
    void prepared(MediaPlayer mp){
        prepared=true;buffering=false;dimensions(mp.getVideoWidth(),mp.getVideoHeight());
        try{for(MediaPlayer.TrackInfo track:mp.getTrackInfo()){
            MediaFormat format=track.getFormat();if(format==null)continue;
            String mime=format.containsKey(MediaFormat.KEY_MIME)?format.getString(MediaFormat.KEY_MIME):"";
            if(track.getTrackType()==MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_VIDEO){
                videoCodec=codec(mime);
                if(format.containsKey(MediaFormat.KEY_FRAME_RATE)){
                    try{frameRate=String.format(Locale.GERMANY,"%.2f",format.getFloat(MediaFormat.KEY_FRAME_RATE));}
                    catch(Exception e){try{frameRate=""+format.getInteger(MediaFormat.KEY_FRAME_RATE);}catch(Exception ignored){}}
                }
            }else if(track.getTrackType()==MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO)audioCodec=codec(mime);
        }}catch(Exception ignored){}
        reveal();
    }
    private static String codec(String mime){
        if(mime==null||mime.isEmpty())return "—";
        if(mime.equals("video/avc"))return "H.264";if(mime.equals("video/hevc"))return "H.265";
        if(mime.equals("audio/mp4a-latm"))return "AAC";if(mime.equals("audio/ac3"))return "AC3";
        if(mime.equals("audio/eac3"))return "E-AC3";
        return mime.substring(mime.indexOf('/')+1).toUpperCase(Locale.ROOT);
    }
    private boolean isRunning(){try{return video.isPlaying();}catch(Exception e){return false;}}
    private int position(){try{return prepared?Math.max(0,video.getCurrentPosition()):0;}catch(Exception e){return 0;}}
    private int length(){try{return prepared?Math.max(0,video.getDuration()):0;}catch(Exception e){return 0;}}
    private void reveal(){shown=true;hideAt=SystemClock.uptimeMillis()+6500;invalidate();}
    private void toggle(){if(!prepared){reveal();return;}try{if(video.isPlaying())video.pause();else video.start();}catch(Exception ignored){}reveal();}
    private void seek(int delta){if(!live&&prepared){int len=length();if(len>0)video.seekTo((int)Math.max(0,Math.min((long)len-1,(long)position()+delta)));}reveal();}
    @Override public boolean onKeyDown(int key,KeyEvent event){
        switch(key){
            case KeyEvent.KEYCODE_DPAD_CENTER:case KeyEvent.KEYCODE_ENTER:
                if(event.getRepeatCount()==0){if(!shown)reveal();else toggle();}return true;
            case KeyEvent.KEYCODE_INFO:case KeyEvent.KEYCODE_MENU:reveal();return true;
            case KeyEvent.KEYCODE_DPAD_UP:case KeyEvent.KEYCODE_DPAD_DOWN:reveal();return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:if(event.getRepeatCount()==0)toggle();return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:if(prepared)video.start();reveal();return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:if(prepared)video.pause();reveal();return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:case KeyEvent.KEYCODE_MEDIA_REWIND:seek(-10000);return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:seek(10000);return true;
            default:return super.onKeyDown(key,event);
        }
    }
    @Override public boolean onTouchEvent(MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_UP){if(shown)toggle();else reveal();performClick();}return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
    private void rect(Canvas c,float x,float y,float w,float h,int color){paint.setColor(color);c.drawRect(x,y,x+w,y+h,paint);}
    private void text(Canvas c,String value,float x,float baseline,float size,int color,float max){
        paint.setColor(color);paint.setTextSize(size);String s=value==null?"":value;
        if(paint.measureText(s)>max){int n=paint.breakText(s,true,Math.max(0,max-paint.measureText("…")),null);s=s.substring(0,n)+"…";}
        c.drawText(s,x,baseline,paint);
    }
    private static String time(long ms){long sec=Math.max(0,ms)/1000;return String.format(Locale.GERMANY,"%02d:%02d:%02d",sec/3600,sec/60%60,sec%60);}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);if(!shown)return;
        float scale=Math.min(getWidth()/1920f,getHeight()/1080f);
        c.save();c.translate((getWidth()-1920*scale)/2,(getHeight()-1080*scale)/2);c.scale(scale,scale);
        int white=0xffeeeeee,cyan=0xff2fc5df,muted=0xffb8c2cd;
        rect(c,0,800,1920,280,0xd906172b);rect(c,0,800,1920,3,cyan);
        rect(c,1288,818,2,236,cyan);rect(c,1675,836,2,160,cyan);
        if(poster!=null){float fit=Math.min(190f/poster.getWidth(),190f/poster.getHeight());float w=poster.getWidth()*fit,h=poster.getHeight()*fit;
            c.drawBitmap(poster,null,new RectF(48+(190-w)/2,843+(190-h)/2,48+(190+w)/2,843+(190+h)/2),paint);
        }else{text(c,live?"LIVE":"FILM",48,920,29,cyan,190);}
        text(c,live?"LIVE":"VOD",320,865,30,white,95);
        text(c,item.name,420,865,38,white,835);
        text(c,width>0&&height>0?width+"×"+height:"Auflösung: —",325,913,20,muted,220);
        text(c,frameRate+" FPS",555,913,20,muted,150);
        text(c,"VIDEO: "+videoCodec,740,913,20,cyan,240);
        text(c,"AUDIO: "+audioCodec,1000,913,20,cyan,260);
        int pos=position(),len=length();float fraction=0;
        if(live){GuideData.Program now=schedule==null?null:schedule.now(System.currentTimeMillis());
            text(c,now==null?"LIVE-TV":now.title,300,960,25,white,950);
            if(now!=null){SimpleDateFormat fmt=new SimpleDateFormat("HH:mm",Locale.GERMANY);
                text(c,fmt.format(new Date(now.start))+" – "+fmt.format(new Date(now.end)),300,1003,20,muted,950);
                fraction=Math.max(0,now.percent(System.currentTimeMillis()))/100f;}
        }else{ text(c,"VERSTRICHEN",300,960,20,cyan,220);text(c,time(pos),535,960,23,white,300);
            text(c,"VERBLEIBEND",300,1003,20,muted,220);text(c,len>0?time((long)len-pos):"—",535,1003,23,muted,300);
            if(len>0)fraction=Math.min(1,pos/(float)len);
        }
        rect(c,300,1045,975,6,0xff304359);rect(c,300,1045,975*fraction,6,cyan);
        text(c,buffering?"Wird geladen …":!prepared?"Verbinden …":!isRunning()?"PAUSE":live?"OK: Pause · Info: Einblenden":"OK: Pause · ◀ ▶: ±10 Sekunden",300,1076,17,muted,975);
        text(c,"WETTER",1390,865,21,muted,250);text(c,"—",1468,925,35,white,170);
        text(c,"Nicht eingerichtet",1350,974,19,muted,300);
        Date date=new Date();text(c,new SimpleDateFormat("HH:mm",Locale.GERMANY).format(date),1720,920,45,white,190);
        text(c,new SimpleDateFormat("dd.MM.yyyy",Locale.GERMANY).format(date),1717,977,20,muted,190);
        text(c,"Zurück: Beenden",1695,1047,18,muted,220);
        c.restore();
    }
}
