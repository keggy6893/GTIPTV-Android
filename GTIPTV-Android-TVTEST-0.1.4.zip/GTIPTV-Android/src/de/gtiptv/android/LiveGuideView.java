// SPDX-License-Identifier: GPL-2.0-or-later
// Geometry and artwork: GT IPTV Player Pro, Copyright (C) 2026 VicTuS59.
package de.gtiptv.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

final class LiveGuideView extends View {
    interface Actions {
        void play(Catalog.Item item);
        void favorite(Catalog.Item item);
        boolean isFavorite(Catalog.Item item);
        void menu(Catalog.Item item);
        void refresh();
        void back();
    }
    private static final LruCache<String,Bitmap> LOGOS=new LruCache<String,Bitmap>(12*1024*1024){
        @Override protected int sizeOf(String key,Bitmap value){return value.getByteCount();}
    };
    private static final LruCache<String,GuideData.Schedule> EPG=new LruCache<>(80);
    private final Catalog.Source source;
    private final List<Catalog.Item> items;
    private final Actions actions;
    private final ExecutorService workers;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final Map<String,Bitmap> artwork=new HashMap<>();
    private final Set<String> requests=new HashSet<>();
    private final List<Future<?>> jobs=new ArrayList<>();
    private int selected,page;
    private boolean closed=false;
    private float scale=1,offsetX=0,offsetY=0;
    private final Runnable ticker=new Runnable(){public void run(){if(!closed){invalidate();ui.postDelayed(this,1000);}}};

    LiveGuideView(Context context,Catalog.Source source,List<Catalog.Item> items,int initial,ExecutorService workers,Actions actions){
        super(context);this.source=source;this.items=new ArrayList<>(items);this.workers=workers;this.actions=actions;
        selected=Math.max(0,Math.min(items.size()-1,initial));page=(selected/10)*10;
        setFocusable(true);setFocusableInTouchMode(true);setBackgroundColor(0xff050914);
        String[] names={"screen-live-guide-r89-1080.png","remote-key-cyan-v42.png","remote-key-red-v42.png","remote-key-green-v42.png","remote-key-neutral-v42.png","favorite-star-v15.png"};
        for(String name:names){try(InputStream in=context.getAssets().open("art/"+name)){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)artwork.put(name,b);}catch(Exception ignored){}}
    }
    int selection(){return selected;}
    static void clearGuideCache(){EPG.evictAll();}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();closed=false;ui.post(ticker);loadVisible();}
    @Override protected void onDetachedFromWindow(){closed=true;ui.removeCallbacksAndMessages(null);for(Future<?> job:jobs)job.cancel(true);jobs.clear();super.onDetachedFromWindow();}
    private void loadVisible(){
        if(items.isEmpty())return;
        load(items.get(selected));
        for(int n=page;n<Math.min(page+10,items.size());n++)if(n!=selected)load(items.get(n));
        setContentDescription("Kanalliste. "+(selected+1)+" von "+items.size()+". "+items.get(selected).name+". OK Wiedergabe, links oder rechts Seite, rote Taste Favorit, Menü Aktionen.");
        invalidate();
    }
    private void load(Catalog.Item item){
        GuideData.Schedule cached=EPG.get(item.key());
        if(source.type.equals("xtream")&&(cached==null||System.currentTimeMillis()-cached.fetched>90000)&&requests.add("epg:"+item.key())){
            jobs.add(workers.submit(()->{
                GuideData.Schedule schedule;
                try{schedule=GuideData.schedule(source,item);}catch(Exception e){schedule=new GuideData.Schedule();}
                EPG.put(item.key(),schedule);
                ui.post(()->{if(!closed){requests.remove("epg:"+item.key());invalidate();}});
            }));
        }
        if(!item.icon.isEmpty()&&LOGOS.get(item.icon)==null&&requests.add("logo:"+item.icon)){
            jobs.add(workers.submit(()->{
                try{Bitmap logo=GuideData.logo(item.icon);if(logo!=null)LOGOS.put(item.icon,logo);}catch(Exception ignored){}
                // Failed logo requests remain deduplicated for this screen lifetime.
                ui.post(()->{if(!closed)invalidate();});
            }));
        }
    }
    private void fill(Canvas c,float x,float y,float w,float h,int color){paint.setStyle(Paint.Style.FILL);paint.setColor(color);c.drawRect(x,y,x+w,y+h,paint);}
    private void line(Canvas c,float x,float y,float w,int color){fill(c,x,y,w,1,color);}
    private void text(Canvas c,String value,float x,float y,float w,float h,float font,int color,boolean center){
        paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));paint.setTextSize(font);paint.setColor(color);paint.setStyle(Paint.Style.FILL);
        String string=TextUtils.ellipsize(value==null?"":value,new android.text.TextPaint(paint),Math.max(1,w),TextUtils.TruncateAt.END).toString();
        Paint.FontMetrics fm=paint.getFontMetrics();float baseline=y+h/2-(fm.ascent+fm.descent)/2;
        c.save();c.clipRect(x,y,x+w,y+h);c.drawText(string,center?x+(w-paint.measureText(string))/2:x,baseline,paint);c.restore();
    }
    private void image(Canvas c,Bitmap image,float x,float y,float w,float h,boolean fit){
        if(image==null||image.isRecycled())return;RectF target=new RectF(x,y,x+w,y+h);
        if(fit){float s=Math.min(w/image.getWidth(),h/image.getHeight());float iw=image.getWidth()*s,ih=image.getHeight()*s;target.set(x+(w-iw)/2,y+(h-ih)/2,x+(w+iw)/2,y+(h+ih)/2);}
        paint.setColor(Color.WHITE);c.drawBitmap(image,null,target,paint);
    }
    private void outline(Canvas c,float x,float y,float w,float h,int color){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2);paint.setColor(color);c.drawRect(x,y,x+w,y+h,paint);paint.setStyle(Paint.Style.FILL);}
    private String time(long value){return value<=0?"--:--":new SimpleDateFormat("HH:mm",Locale.GERMANY).format(new Date(value));}
    private void progress(Canvas c,float x,float y,float width,int percent){fill(c,x,y,width,10,0xff26313a);if(percent>0)fill(c,x,y,width*percent/100f,10,0xff24a9f2);}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);scale=Math.min(getWidth()/1920f,getHeight()/1080f);offsetX=(getWidth()-1920*scale)/2;offsetY=(getHeight()-1080*scale)/2;
        c.save();c.translate(offsetX,offsetY);c.scale(scale,scale);
        image(c,artwork.get("screen-live-guide-r89-1080.png"),0,0,1920,1080,false);
        long now=System.currentTimeMillis();Date date=new Date(now);
        text(c,new SimpleDateFormat("HH:mm:ss",Locale.GERMANY).format(date),60,5,240,35,28,0xff5cc7ff,true);
        text(c,new SimpleDateFormat("EEE",Locale.GERMANY).format(date),60,39,240,20,16,0xff68d8ff,true);
        text(c,new SimpleDateFormat("dd.MM.yyyy",Locale.GERMANY).format(date),60,59,240,20,16,0xff68d8ff,true);
        text(c,"GT IPTV PLAYER PRO  •  LIVE-TV",430,0,1060,88,38,0xff74c9ff,true);
        line(c,8,88,414,0xff244050);line(c,432,88,952,0xff244050);line(c,1394,88,518,0xff244050);
        text(c,"KANALLISTE",454,100,650,55,33,0xff63c7ff,false);
        text(c,(selected+1)+" / "+items.size(),1240,100,120,55,26,0xffe1e6ed,true);line(c,454,157,908,0xff26343f);
        for(int slot=0;slot<10;slot++){
            int index=page+slot;if(index>=items.size())break;Catalog.Item item=items.get(index);int y=166+slot*78;
            if(index==selected){fill(c,446,y,924,72,0xff14375e);outline(c,447,y+1,922,70,0xff58a6ff);fill(c,446,y,7,72,0xff2f75c9);}
            line(c,446,y+71,924,0xff294b60);
            text(c,String.format(Locale.GERMANY,"%04d",index+1),458,y,102,72,27,0xffd7dee8,false);
            image(c,LOGOS.get(item.icon),564,y+6,110,60,true);
            text(c,item.name,685,y,310,72,29,0xfff8fafc,false);
            GuideData.Schedule schedule=EPG.get(item.key());GuideData.Program current=schedule==null?null:schedule.now(now);
            text(c,current==null?"":current.title,1006,y,238,72,22,0xffccd3dd,false);
            progress(c,1258,y+31,96,current==null?-1:current.percent(now));
            if(actions.isFavorite(item))image(c,artwork.get("favorite-star-v15.png"),653,y+5,22,22,true);
        }
        fill(c,1375,166,4,774,0xff1c2a35);int thumb=Math.max(30,774*Math.min(10,items.size())/Math.max(1,items.size()));
        float pos=items.size()<=10?0:Math.min(1,page/(float)(items.size()-10));fill(c,1375,166+(774-thumb)*pos,4,thumb,0xff32b8f2);
        if(!items.isEmpty())drawDetails(c,items.get(selected),now);
        footer(c,62,"▲ ▼","AUSWÄHLEN","remote-key-cyan-v42.png",160,340);
        footer(c,389,"◀ ▶","SEITE","remote-key-cyan-v42.png",488,605);
        footer(c,654,"OK","WIEDERGEBEN","remote-key-cyan-v42.png",752,950);
        footer(c,1000,"","FAVORIT","remote-key-red-v42.png",1100,1240);
        footer(c,1290,"","AKTUALISIEREN","remote-key-green-v42.png",1388,1600);
        footer(c,1650,"EXIT","ZURÜCK","remote-key-neutral-v42.png",1750,1900);
        c.restore();
    }
    private void drawDetails(Canvas c,Catalog.Item item,long now){
        image(c,LOGOS.get(item.icon),34,116,362,220,true);
        text(c,item.name.toUpperCase(Locale.GERMANY),34,348,362,55,29,0xfff8fafc,true);line(c,34,414,362,0xff253440);
        text(c,"JETZT",34,429,362,38,26,0xff3eb8ff,false);
        GuideData.Schedule schedule=EPG.get(item.key());GuideData.Program current=schedule==null?null:schedule.now(now);
        text(c,current==null?(schedule==null&&source.type.equals("xtream")?"EPG wird geladen …":"Keine EPG-Daten"):current.title,34,475,362,52,29,Color.WHITE,false);
        text(c,current==null?"--:-- – --:--":time(current.start)+"–"+time(current.end),34,534,260,40,21,0xffd7dee8,false);
        text(c,current==null?"--%":current.percent(now)+"%",332,534,64,40,21,0xffd7dee8,true);progress(c,34,578,362,current==null?-1:current.percent(now));line(c,34,612,362,0xff1d2a34);
        if(current!=null)paragraph(c,current.description,34,633,362,280,23,0xffd2d9e1);
        fill(c,1405,111,495,281,0xff03080c);outline(c,1406,112,493,279,0xff477b89);text(c,"KANAL AUSWÄHLEN",1415,319,475,56,20,0xff8998a5,true);
        text(c,current==null?"--:--":time(current.start),1416,410,100,56,22,0xffdce3eb,false);
        text(c,current==null?"Keine EPG-Daten":current.title,1526,410,366,56,22,0xfff5f7fa,false);line(c,1414,482,478,0xff26343f);
        text(c,"WEITER",1414,514,478,54,29,0xff3eb8ff,false);
        List<GuideData.Program> next=schedule==null?new ArrayList<>():schedule.next(now);
        for(int n=0;n<4;n++){int y=610+n*74;GuideData.Program p=n<next.size()?next.get(n):null;
            text(c,p==null?"--:--":time(p.start),1416,y,112,56,22,0xffdce3eb,false);text(c,p==null?"--":p.title,1532,y,360,56,22,0xfff5f7fa,false);}
        line(c,1414,918,478,0xff26343f);
    }
    private void paragraph(Canvas c,String value,float x,float y,float width,float height,int font,int color){
        android.text.TextPaint tp=new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG);tp.setTextSize(font);tp.setColor(color);
        android.text.StaticLayout layout=android.text.StaticLayout.Builder.obtain(value,0,value.length(),tp,(int)width).setMaxLines(10).setEllipsize(TextUtils.TruncateAt.END).build();
        c.save();c.clipRect(x,y,x+width,y+height);c.translate(x,y);layout.draw(c);c.restore();
    }
    private void footer(Canvas c,int x,String key,String label,String artworkName,int labelX,int divider){
        image(c,artwork.get(artworkName),x,996,77,50,false);text(c,key,x,996,77,50,21,Color.WHITE,true);text(c,label,labelX,990,divider-labelX,60,23,0xffc8d2e3,false);
        if(divider<1900)fill(c,divider,992,3,60,0xff1683a8);
    }
    private void move(int count,boolean wrap){if(items.isEmpty())return;selected=wrap?Math.floorMod(selected+count,items.size()):Math.max(0,Math.min(items.size()-1,selected+count));page=(selected/10)*10;loadVisible();}
    @Override public boolean onKeyDown(int key,KeyEvent event){
        if(items.isEmpty())return super.onKeyDown(key,event);
        switch(key){
            case KeyEvent.KEYCODE_DPAD_UP:move(-1,true);return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:move(1,true);return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:case KeyEvent.KEYCODE_PAGE_UP:move(-10,false);return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:case KeyEvent.KEYCODE_PAGE_DOWN:move(10,false);return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:case KeyEvent.KEYCODE_ENTER:actions.play(items.get(selected));return true;
            case KeyEvent.KEYCODE_PROG_RED:actions.favorite(items.get(selected));invalidate();return true;
            case KeyEvent.KEYCODE_PROG_GREEN:actions.refresh();return true;
            case KeyEvent.KEYCODE_MENU:actions.menu(items.get(selected));return true;
            default:return super.onKeyDown(key,event);
        }
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP)return true;
        float x=(e.getX()-offsetX)/scale,y=(e.getY()-offsetY)/scale;
        if(x>=446&&x<1370&&y>=166&&y<940){int n=page+(int)((y-166)/78);if(n<items.size()){selected=n;loadVisible();}return true;}
        if(y>=980&&!items.isEmpty()){
            if(x<347)move(1,true);else if(x<613)move(10,false);else if(x<958)actions.play(items.get(selected));else if(x<1248){actions.favorite(items.get(selected));invalidate();}else if(x<1608)actions.refresh();else actions.back();
        }return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
